# Scraper — código-fonte

`desenvolvimento/` contém os arquivos modificados do Scraper, scripts do sistema, traduções e recursos necessários, organizados conforme os caminhos do CrossMix. Os arquivos `tests_*.py` são testes locais; `AUDITORIA.md` e `LEIA-ME.txt` registram informações e limitações do projeto.

Para gerar um novo pacote de instalação a partir desta pasta, execute `python gerar_pacote.py`. O comando cria `Scraper-atualizado.zip` e atualiza em `instalar-scraper.sh` o hash esperado desse ZIP. Os testes locais têm dependências do ambiente Windows e de ferramentas externas e podem precisar de ajustes em seus caminhos. No console, o aplicativo depende dos utilitários e componentes do CrossMix.

Base: CrossMix-OS v1.3.0, https://github.com/cizia64/CrossMix-OS/releases/tag/v1.3.0 . Os fontes modificados aqui são os de `desenvolvimento`; `upstream-commit.txt` registra informação adicional sobre a referência original.

A indicação do progresso sobre outras telas depende dos recursos de OSD disponíveis no firmware. Sua posição e permanência, o cancelamento e a integração com o aparelho não foram validados em um Trimui físico.
