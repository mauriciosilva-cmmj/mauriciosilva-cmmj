import pathlib,subprocess,tempfile,os,json
root=pathlib.Path.cwd();sh=r'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1123-915-0_26.1123.915.0_x64__3k8sg7r9htsxt\dependencies\native\git\usr\bin\sh.exe'
def ux(p):
 s=pathlib.Path(p).as_posix();return '/'+s[0].lower()+s[2:] if len(s)>2 and s[1]==':' else s
with tempfile.TemporaryDirectory(prefix='scraper-osd-test-',dir=root) as d:
 p=pathlib.Path(d);(p/'bin').mkdir();(p/'osd').mkdir();(p/'lock').mkdir();status=p/'status.json';status.write_text(json.dumps({'system':'MD','processed':4,'total':10,'percent':40,'downloaded':2}))
 (p/'idioma.sh').write_text('SCRAPER_PT=1\n');mock=p/'jq.py'
 mock.write_text('''import sys,json\na=sys.argv[1:]\nif "-n" in a or "-cn" in a:\n print(json.dumps({"message":a[a.index("--arg")+2],"duration":2500,"x":710,"y":4}));sys.exit()\nd=json.load(open(a[-1]));print("|".join(str(d.get(k,0)) for k in ["system","processed","total","percent","downloaded"]))\n''')
 jq=p/'bin/jq';jq.write_text('#!/bin/sh\nexec "'+pathlib.Path(os.sys.executable).as_posix()+'" "'+mock.as_posix()+'" "$@"\n');jq.chmod(0o755)
 s=(root/'desenvolvimento/Apps/Scraper/osd-progresso.sh').read_text(encoding='utf8').replace('/mnt/SDCARD/Apps/Scraper/idioma.sh',ux(p/'idioma.sh')).replace('/tmp/crossmix_scraper_progress/status.json',ux(status)).replace('/tmp/crossmix_scraper_progress/lock/pid',ux(p/'lock/pid')).replace('/tmp/trimui_osd',ux(p/'osd')).replace('    sleep 2\n','    break\n')
 (p/'osd.sh').write_text(s);(p/'test.sh').write_text('#!/bin/sh\nprintf "%s\\n" "$$" > "'+ux(p/'lock/pid')+'"\nsh "'+ux(p/'osd.sh')+'" "$$"\n')
 env=os.environ.copy();env['PATH']=str(p/'bin')+os.pathsep+str(pathlib.Path(sh).parent)+os.pathsep+env['PATH']
 r=subprocess.run([sh,str(p/'test.sh')],env=env,capture_output=True,text=True,timeout=20);print('OSD shell exit:',r.returncode,'stderr',r.stderr.strip());assert r.returncode==0
 data=json.loads((p/'osd/osd_toast_msg').read_text());print('Mensagem OSD simulada:',data);assert data['message']=='Consulta MD 4/10 - 40% D:2' and data['y']==4
print('Geracao de mensagem OSD: OK (compositor real nao testado)')
