import json,pathlib,subprocess,tempfile,os
root=pathlib.Path.cwd();sh=r'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1123-915-0_26.1123.915.0_x64__3k8sg7r9htsxt\dependencies\native\git\usr\bin\sh.exe'
source=(root/'desenvolvimento/System/usr/trimui/scripts/scraper/scrap_screenscraper.sh').read_text(encoding='utf8')
start=source.index('progress_write() {');end=source.index('\nprogress_write running 0',start)
fn=source[start:end]
with tempfile.TemporaryDirectory(prefix='scraper-progress-test-',dir=root) as d:
 temp=pathlib.Path(d);(temp/'bin').mkdir(); out=temp/'status.json'
 stub=temp/'mock_jq.py';stub.write_text('''import sys,json\na=sys.argv[1:]; out={}; i=0\nwhile i<len(a):\n if a[i] in ("--arg","--argjson"):\n  mode=a[i]; key=a[i+1]; value=a[i+2];out[key]=json.loads(value) if mode=="--argjson" else value;i+=3\n else:i+=1\nprint(json.dumps(out))\n''')
 py=pathlib.Path(os.sys.executable).as_posix();cmd=stub.as_posix();jq=temp/'bin/jq';jq.write_text('#!/bin/sh\nexec "'+py+'" "'+cmd+'" "$@"\n')
 posix=lambda p:'/c/'+p.as_posix()[3:] if p.as_posix()[1:3]==':/' else p.as_posix()
 script='''#!/bin/sh
status_dir="'''+posix(temp)+'''"
status_file="$status_dir/status.json"
CurrentSystem=MD
rom_total=10
Scrap_Success=0
Scrap_notrequired=0
Scrap_Fail=0
'''+fn+'''
progress_write running 0 || exit 1
Scrap_Success=2
Scrap_notrequired=1
progress_write running 4 || exit 2
'''
 test=temp/'case.sh';test.write_text(script)
 env=os.environ.copy();env['PATH']=str(temp/'bin')+os.pathsep+str(pathlib.Path(sh).parent)+os.pathsep+env['PATH']
 # sh maps Windows paths and tools to its own POSIX environment.
 r=subprocess.run([sh,str(test)],env=env,capture_output=True,text=True)
 print('Status shell exit:',r.returncode,'stderr:',r.stderr.strip());assert r.returncode==0
 data=json.loads(out.read_text());print('Estado simulado:',data)
 assert (data['processed'],data['total'],data['downloaded'],data['existing'],data['failed'],data['percent'])==(4,10,2,1,1,40)
 assert data['system']=='MD' and data['phase']=='running'
 print('Contagem e gravacao atomica: OK')
