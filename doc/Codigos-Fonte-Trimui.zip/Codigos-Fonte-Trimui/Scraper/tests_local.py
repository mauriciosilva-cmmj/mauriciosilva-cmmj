from pathlib import Path
import sqlite3,subprocess,os
root=Path.cwd();src=root/'desenvolvimento';shell=Path(r'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1123-915-0_26.1123.915.0_x64__3k8sg7r9htsxt\dependencies\native\git\usr\bin\sh.exe')
files=list(src.rglob('*.sh'))+list(src.rglob('*.launch'));bad=[]
for file in files:
 p=subprocess.run([str(shell),'-n',str(file)],capture_output=True,text=True)
 if p.returncode:bad.append((str(file),p.stderr))
print('Shell:',len(files),'arquivos; erros:',bad)
assert not bad
c=sqlite3.connect(':memory:');c.execute('CREATE TABLE Menu_roms(id integer primary key,disp text,path text,imgpath text,type int,ppath text,pinyin text,cpinyin text,opinyin text)')
def add(d,p,par,t=1):c.execute('insert into Menu_roms(disp,path,imgpath,type,ppath,pinyin,cpinyin,opinyin) values(?,?,?,?,?,?,?,?)',(d,p,'',t,par,d,d,d))
add('Configuration','/Menu/Configuration','.')
add('Media Type (box-2D)','/Menu/Configuration##Media Type (value)','Configuration')
add('box-2D (Box Art)','/Menu/Configuration##Media Type (value)/box-2D (Box Art).sh','Media Type (box-2D)',0)
add('Region (br)','/Menu/Configuration##Region (value)','Configuration')
add('American continent','/Menu/Region (value)##American continent','Region (br)')
add('br - Brazil','/Menu/Region (value)##American continent/br - Brazil.sh','American continent',0)
add('! Progresso','/Menu/! Progresso.sh','.',0)
add('! Cancelar','/Menu/! Cancelar.sh','.',0)
c.commit();c.executescript((src/'Apps/Scraper/traducao-pt.sql').read_text(encoding='utf8'))
for row in c.execute('select disp,ppath,path from Menu_roms order by id'): print('  ',row)
assert c.execute("select disp from Menu_roms where path='/Menu/Configuration'").fetchone()[0]=='Configuracoes'
assert c.execute("select ppath from Menu_roms where path like '%box-2D%sh'").fetchone()[0]=='Tipo de midia (box-2D)'
assert c.execute("select ppath from Menu_roms where path like '%Brazil.sh'").fetchone()[0]=='America'
assert c.execute("select disp from Menu_roms where path like '%Brazil.sh'").fetchone()[0]=='br - Brasil'
assert c.execute("select disp from Menu_roms where path='/Menu/! Progresso.sh'").fetchone()[0]=='! Progresso da consulta'
before=list(c.execute('select disp,ppath,path from Menu_roms order by id'))
c.executescript((src/'Apps/Scraper/traducao-pt.sql').read_text(encoding='utf8'))
assert list(c.execute('select disp,ppath,path from Menu_roms order by id'))==before
print('Traducao do menu e referencias hierarquicas: OK')
