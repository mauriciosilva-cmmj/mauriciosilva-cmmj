#!/bin/sh
PATH="/mnt/SDCARD/System/bin:$PATH"
. /mnt/SDCARD/Apps/Scraper/idioma.sh
status=/tmp/crossmix_scraper_progress/status.json
if [ ! -r "$status" ]; then
    if [ "$SCRAPER_PT" = 1 ]; then msg='Nenhuma consulta em andamento.'; else msg='No scraping task running.'; fi
else
    snapshot=$(jq -r '[.system // "-", .phase // "-", .processed // 0, .total // 0, .percent // 0, .downloaded // 0, .existing // 0, .failed // 0] | map(tostring) | join("|")' "$status" 2>/dev/null)
    IFS='|' read -r sys phase done total pct ok exists fail <<EOF
$snapshot
EOF
    if [ "$SCRAPER_PT" = 1 ]; then
        case "$phase" in preparing) phase='Preparando';; running) phase='Consultando';; finished) phase='Concluido';; cancelled) phase='Cancelado';; interrupted) phase='Interrompido';; error) phase='Erro';; esac
    fi
    if [ "$SCRAPER_PT" = 1 ]; then
        msg="Sistema: $sys | $done/$total - $pct% | Baixadas: $ok | Existentes: $exists | Falhas: $fail | Estado: $phase"
    else
        msg="System: $sys | $done/$total - $pct% | Downloaded: $ok | Existing: $exists | Errors: $fail | State: $phase"
    fi
fi
/mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh -m "$msg" -t 8
