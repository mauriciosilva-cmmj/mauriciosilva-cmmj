#!/bin/sh
PATH="/mnt/SDCARD/System/bin:$PATH"
export LD_LIBRARY_PATH="/mnt/SDCARD/System/lib:/usr/trimui/lib:$LD_LIBRARY_PATH"
. /mnt/SDCARD/Apps/Scraper/idioma.sh

script_name=$(basename "$0" .sh)
lang_code=$(echo "$script_name" | cut -d ' ' -f 1 | cut -d '-' -f 1)

if [ "$SCRAPER_PT" = 1 ]; then notice="Configuracao atualizada"; else notice="Setting updated"; fi
/mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh -m "$notice"

json_file="/mnt/SDCARD/System/etc/scraper.json"

if [ ! -f "$json_file" ]; then
  echo "{}" >"$json_file"
fi

/mnt/SDCARD/System/bin/jq --arg lang_code "$lang_code" '.Screenscraper_Region = $lang_code' "$json_file" >"/tmp/json_file.tmp" && mv "/tmp/json_file.tmp" "$json_file"

# we modify the DB entries to reflect the current state
/mnt/SDCARD/System/usr/trimui/scripts/mainui_state_update.sh "$(if [ "$SCRAPER_PT" = 1 ]; then echo "Regiao"; else echo "Region"; fi)" "$script_name"
