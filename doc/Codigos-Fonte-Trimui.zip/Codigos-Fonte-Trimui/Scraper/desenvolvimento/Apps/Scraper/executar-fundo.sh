#!/bin/sh
# The job owns its lock directory; no process-wide kill is used.
export PATH="/mnt/SDCARD/System/bin:$PATH"
export LD_LIBRARY_PATH="/mnt/SDCARD/System/lib:/usr/trimui/lib:$LD_LIBRARY_PATH"
dir=/tmp/crossmix_scraper_progress
mkdir -p "$dir"
printf '%s\n' "$$" > "$dir/lock/pid"
rm -f "$dir/cancel_all"
cleanup() {
    rm -f "$dir/lock/pid" "$dir/cancel_all"
    rmdir "$dir/lock" 2>/dev/null || :
}
trap cleanup EXIT
trap 'exit 130' HUP INT TERM
export SCRAPER_BACKGROUND=1
jq -n --arg system "$1" --argjson pid "$$" '{system:$system,phase:"preparing",processed:0,total:0,downloaded:0,existing:0,failed:0,percent:0,pid:$pid}' > "$dir/start.$$.tmp" && mv -f "$dir/start.$$.tmp" "$dir/status.json"
/mnt/SDCARD/Apps/Scraper/osd-progresso.sh "$$" </dev/null >/dev/null 2>&1 &
if [ "$1" = '--all' ]; then
    '/mnt/SDCARD/Apps/Scraper/Menu/° Scrape all.launch'
else
    /mnt/SDCARD/System/usr/trimui/scripts/scraper/scrap_screenscraper.sh "$1"
fi
worker_result=$?
if [ "$worker_result" -ne 0 ] && [ -f "$dir/status.json" ]; then
    jq '.phase="error"' "$dir/status.json" > "$dir/end.$$.tmp" && mv -f "$dir/end.$$.tmp" "$dir/status.json"
fi
if [ -f "$dir/cancel_all" ] && [ -f "$dir/status.json" ]; then
    jq '.phase="cancelled"' "$dir/status.json" > "$dir/end.$$.tmp" && mv -f "$dir/end.$$.tmp" "$dir/status.json"
fi
