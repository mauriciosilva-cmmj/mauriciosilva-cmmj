#!/bin/sh
# Best effort OSD: the endpoint is provided by supported stock firmware.
PATH="/mnt/SDCARD/System/bin:$PATH"
. /mnt/SDCARD/Apps/Scraper/idioma.sh
status=/tmp/crossmix_scraper_progress/status.json
while kill -0 "$1" 2>/dev/null && [ "$(cat /tmp/crossmix_scraper_progress/lock/pid 2>/dev/null)" = "$1" ]; do
    if [ -d /tmp/trimui_osd ] && [ -r "$status" ]; then
        # Read one atomic status snapshot so numbers never come from
        # different consoles when the worker changes systems.
        snapshot=$(jq -r '[.system // "", .processed // 0, .total // 0, .percent // 0, .downloaded // 0] | map(tostring) | join("|")' "$status" 2>/dev/null)
        IFS='|' read -r system processed total percent downloaded <<EOF
$snapshot
EOF
        if [ "$SCRAPER_PT" = 1 ]; then title="Consulta"; else title="Scraping"; fi
        msg="$title $system $processed/$total - $percent% D:$downloaded"
        jq -cn --arg message "$msg" '{duration:2500,x:710,y:4,message:$message,font:"",icon:"",fontsize:18}' > /tmp/trimui_osd/osd_toast_msg 2>/dev/null || :
    fi
    sleep 2
 done
