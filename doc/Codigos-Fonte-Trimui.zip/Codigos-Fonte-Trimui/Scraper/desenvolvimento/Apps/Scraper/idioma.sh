#!/bin/sh
# Read the console language without changing its settings.
SCRAPER_LANG=$(jq -r '.language // "en.lang"' /mnt/UDISK/system.json 2>/dev/null)
case "$SCRAPER_LANG" in br.lang|pt.lang|pt_BR*|pt-BR*) SCRAPER_PT=1;; *) SCRAPER_PT=0;; esac
export SCRAPER_PT
