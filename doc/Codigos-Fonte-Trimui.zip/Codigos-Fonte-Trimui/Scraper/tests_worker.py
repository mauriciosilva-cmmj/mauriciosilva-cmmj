import pathlib,tempfile,subprocess,os,json
R=pathlib.Path.cwd(); SH=r'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1123-915-0_26.1123.915.0_x64__3k8sg7r9htsxt\dependencies\native\git\usr\bin\sh.exe'
def ux(p):
 s=pathlib.Path(p).as_posix();return '/'+s[0].lower()+s[2:] if len(s)>2 and s[1]==':' else s
with tempfile.TemporaryDirectory(prefix='scraper-worker-test-',dir=R) as d:
 root=pathlib.Path(d);sd=root/'sd';bin=sd/'System/bin';bin.mkdir(parents=True);state=root/'state';state.mkdir();(sd/'System/etc').mkdir(parents=True);(sd/'Emus/MD').mkdir(parents=True);(sd/'Roms/MD').mkdir(parents=True);(sd/'Imgs/MD').mkdir(parents=True)
 (sd/'System/etc/scraper.json').write_text(json.dumps({'screenscraper_username':'test','screenscraper_password':'test','Screenscraper_MediaType':'box-2D','Screenscraper_Region':'br','ScrapeInBackground':'true'}))
 (sd/'Emus/MD/config.json').write_text(json.dumps({'extlist':'zip'}))
 (sd/'Apps/Scraper').mkdir(parents=True);(sd/'Apps/Scraper/idioma.sh').write_text('SCRAPER_PT=1\n')
 for name in ['a','b','c','d']:(sd/'Roms/MD'/f'{name}.zip').write_bytes(b'rom-data')
 (sd/'Imgs/MD/a.png').write_bytes(b'existing')
 mock=root/'jq.py';mock.write_text('''import json,sys\na=sys.argv[1:]\nif "-n" in a:\n d={};i=0\n while i<len(a):\n  if a[i] in ("--arg","--argjson"):\n   mode=a[i];k=a[i+1];v=a[i+2];d[k]=json.loads(v) if mode=="--argjson" else v;i+=3\n  else:i+=1\n print(json.dumps(d));sys.exit()\nraw="-r" in a\nexpr=next((x for x in a if x.startswith(".Screenscraper_") or x.startswith(".screenscraper_") or x.startswith(".ScrapeInBackground") or x.startswith(".extlist") or x.startswith(".response.") or x.startswith("map(")),"")\nif expr.startswith("map("): print("\\\"http://example.invalid/image\\\"");sys.exit()\ndata=json.load(sys.stdin)\nfor key in expr.lstrip(".").split("."):\n if key:data=data.get(key,{}) if isinstance(data,dict) else {}\nif isinstance(data,str) and raw:print(data)\nelse: print(json.dumps(data))\n''')
 jq=bin/'jq';jq.write_text('#!/bin/sh\nexec "'+pathlib.Path(os.sys.executable).as_posix()+'" "'+mock.as_posix()+'" "$@"\n')
 (bin/'sqlite3').write_text('#!/bin/sh\necho "br;us"\n')
 (bin/'pgrep').write_text('#!/bin/sh\nexit 1\n')
 (bin/'curl').write_text('''#!/bin/sh
printf '%s\\n' '{"response":{"jeu":{"id":123,"medias":[{"type":"box-2D","region":"br","url":"http://example.invalid/image"}]}}}'
''')
 (bin/'wget').write_text('''#!/bin/sh
while [ "$#" -gt 0 ]; do if [ "$1" = -O ]; then shift; printf PNG > "$1"; [ -n "$SCRAPER_TEST_CANCEL_DIR" ] && touch "$SCRAPER_TEST_CANCEL_DIR/cancel_all"; [ -n "$SCRAPER_TEST_WGET_FAIL" ] && exit 1; exit 0; fi; shift; done
exit 1
''')
 for f in bin.iterdir():f.chmod(0o755)
 source=(R/'desenvolvimento/System/usr/trimui/scripts/scraper/scrap_screenscraper.sh').read_text(encoding='utf8')
 source=source.replace('/mnt/SDCARD',ux(sd)).replace('/tmp/crossmix_scraper_progress',ux(state)).replace('/tmp/stay_awake',ux(root/'stay_awake')).replace('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor','/dev/null').replace('sleep 2\n','sleep 0\n')
 script=root/'worker.sh';script.write_text(source,encoding='utf8')
 env=os.environ.copy();env['PATH']=str(bin)+os.pathsep+str(pathlib.Path(SH).parent)+os.pathsep+env['PATH'];env['SCRAPER_BACKGROUND']='1'
 run=subprocess.run([SH,str(script),'MD'],env=env,capture_output=True,text=True,timeout=45)
 status=json.loads((state/'status.json').read_text());print('Caso completo:',status,'exit',run.returncode)
 assert run.returncode==0 and status['phase']=='finished' and status['processed']==4 and status['total']==4 and status['downloaded']==3 and status['existing']==1 and status['failed']==0
 assert (sd/'Imgs/MD/a.png').read_bytes()==b'existing' and all((sd/'Imgs/MD'/f'{x}.png').read_bytes()==b'PNG' for x in ['b','c','d'])
 assert not list((sd/'Imgs/MD').glob('.scraper-*.tmp'))
 for x in ['b','c','d']:(sd/'Imgs/MD'/f'{x}.png').unlink()
 (state/'cancel_all').touch()
 run=subprocess.run([SH,str(script),'MD'],env=env,capture_output=True,text=True,timeout=45)
 status=json.loads((state/'status.json').read_text());print('Caso cancelado:',status,'exit',run.returncode)
 assert run.returncode==0 and status['phase']=='cancelled' and status['processed']==0 and not (sd/'Imgs/MD/b.png').exists()
 (state/'cancel_all').unlink()
 env['SCRAPER_TEST_CANCEL_DIR']=ux(state)
 run=subprocess.run([SH,str(script),'MD'],env=env,capture_output=True,text=True,timeout=45)
 status=json.loads((state/'status.json').read_text());print('Cancelamento durante download:',status)
 assert status['phase']=='cancelled' and status['processed']==1 and status['existing']==1 and status['downloaded']==0
 assert not (sd/'Imgs/MD/b.png').exists() and not list((sd/'Imgs/MD').glob('.scraper-*.tmp'))
 (state/'cancel_all').unlink();env.pop('SCRAPER_TEST_CANCEL_DIR');env['SCRAPER_TEST_WGET_FAIL']='1'
 run=subprocess.run([SH,str(script),'MD'],env=env,capture_output=True,text=True,timeout=45)
 status=json.loads((state/'status.json').read_text());print('Falhas de download:',status)
 assert status['phase']=='finished' and status['processed']==4 and status['existing']==1 and status['downloaded']==0 and status['failed']==3
 assert not list((sd/'Imgs/MD').glob('.scraper-*.tmp'))
 print('Worker, contagens, escrita temporaria, falha e cancelamento durante download: OK')
