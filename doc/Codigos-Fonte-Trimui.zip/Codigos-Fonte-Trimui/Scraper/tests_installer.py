import pathlib,tempfile,subprocess,os,hashlib,shutil
R=pathlib.Path.cwd(); SH=r'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1123-915-0_26.1123.915.0_x64__3k8sg7r9htsxt\dependencies\native\git\usr\bin\sh.exe'
def ux(p):
 s=pathlib.Path(p).as_posix();return '/'+s[0].lower()+s[2:] if len(s)>2 and s[1]==':' else s
with tempfile.TemporaryDirectory(prefix='scraper-installer-test-',dir=R) as d:
 root=pathlib.Path(d); sd=root/'sd';package=root/'pacote';bin=root/'bin';package.mkdir();bin.mkdir()
 for x in ['Apps/Scraper/Menu','Emus/_Scraper','System/usr/trimui/scripts/scraper','System/etc','Roms/MD','Imgs/MD']:(sd/x).mkdir(parents=True,exist_ok=True)
 (sd/'System/usr/trimui/crossmix-version.txt').write_text('1.3.0\n')
 sentinels={'Apps/Scraper/config.json':'custom config','Apps/Scraper/Menu/custom.sh':'custom action','Emus/_Scraper/screenscraper.sh':'old wrapper','System/usr/trimui/scripts/scraper/scrap_screenscraper.sh':'old backend','System/usr/trimui/scripts/scraper/regions.db':'region database','System/etc/scraper.json':'private credential placeholder','Roms/MD/game.zip':'rom untouched','Imgs/MD/game.png':'cover untouched'}
 for name,value in sentinels.items():(sd/name).write_text(value)
 shutil.copy2(R/'Scraper-atualizado.zip',package/'Scraper-atualizado.zip')
 text=(R/'instalar-scraper.sh').read_text(encoding='utf8').replace('sd=/mnt/SDCARD','sd='+ux(sd))
 (package/'instalar-scraper.sh').write_text(text,encoding='utf8')
 fake=root/'fake.py';fake.write_text('''import sys,zipfile,hashlib,pathlib\ncmd=sys.argv[1];a=sys.argv[2:]\nif cmd=="pgrep":sys.exit(1)\nif cmd in ("sync","chmod"):sys.exit(0)\nif cmd=="tee":\n data=sys.stdin.read();sys.stdout.write(data);p=pathlib.Path(a[-1]);path=p.as_posix()\n if path.startswith("/c/"):p=pathlib.Path("C:/"+path[3:])\n with p.open("a",encoding="utf8") as f:f.write(data)\n sys.exit(0)\nif cmd=="unzip":\n path=next(x for x in a if x.endswith(".zip"));z=zipfile.ZipFile(path)\n if "-t" in a:sys.exit(0 if z.testzip() is None else 1)\n z.extractall(a[a.index("-d")+1]);sys.exit(0)\nif cmd=="sha256sum":\n f=a[a.index("-c")+1];lines=sys.stdin.read().splitlines() if f=="-" else pathlib.Path(f).read_text(encoding="utf8").splitlines()\n for line in lines:\n  h,p=line.split("  ",1);p=pathlib.Path(p);s=p.as_posix()\n  if s.startswith("/c/"):p=pathlib.Path("C:/"+s[3:])\n  if hashlib.sha256(p.read_bytes()).hexdigest()!=h:sys.exit(1)\n sys.exit(0)\n''')
 for name in ['unzip','sha256sum','pgrep','sync','tee','chmod']:
  file=bin/name;file.write_text('#!/bin/sh\nexec "'+pathlib.Path(os.sys.executable).as_posix()+'" "'+fake.as_posix()+'" '+name+' "$@"\n');file.chmod(0o755)
 env=os.environ.copy();env['PATH']=str(bin)+os.pathsep+str(pathlib.Path(SH).parent)+os.pathsep+env['PATH']
 run=subprocess.run([SH,str(package/'instalar-scraper.sh')],env=env,capture_output=True,text=True,timeout=45)
 print('Installer exit:',run.returncode,'output:',run.stdout[-500:],'error:',run.stderr[-500:]);assert run.returncode==0
 for name in ['Apps/Scraper/config.json','Apps/Scraper/Menu/custom.sh','System/usr/trimui/scripts/scraper/regions.db','System/etc/scraper.json','Roms/MD/game.zip','Imgs/MD/game.png']:
  assert (sd/name).read_text()==sentinels[name],name
 assert 'crossmix_scraper_progress' in (sd/'Emus/_Scraper/screenscraper.sh').read_text()
 backups=list((sd/'Apps').glob('Scraper-backup-*'));assert len(backups)==1
 assert (backups[0]/'Emus/_Scraper/screenscraper.sh').read_text()=='old wrapper'
 assert (backups[0]/'System/usr/trimui/scripts/scraper/scrap_screenscraper.sh').read_text()=='old backend'
 (sd/'System/etc/scraper.json').unlink()
 runFresh=subprocess.run([SH,str(package/'instalar-scraper.sh')],env=env,capture_output=True,text=True,timeout=45)
 assert runFresh.returncode==0,runFresh.stderr
 import json
 default=json.loads((sd/'System/etc/scraper.json').read_text())
 assert default['screenscraper_password']=='' and default['Screenscraper_MediaType']=='box-2D'
 assert len(list((sd/'Apps').glob('Scraper-backup-*')))==2
 package_zip=package/'Scraper-atualizado.zip';package_zip.write_bytes(package_zip.read_bytes()+b'tampered')
 run2=subprocess.run([SH,str(package/'instalar-scraper.sh')],env=env,capture_output=True,text=True,timeout=30)
 assert run2.returncode!=0 and 'nao corresponde' in run2.stderr
 assert json.loads((sd/'System/etc/scraper.json').read_text())==default
 assert len(list((sd/'Apps').glob('Scraper-backup-*')))==2
 print('Instalacao simulada, backup, preservacao e rejeicao de ZIP alterado: OK')
