import pathlib,tempfile,subprocess,os
R=pathlib.Path.cwd();SH=r'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1123-915-0_26.1123.915.0_x64__3k8sg7r9htsxt\dependencies\native\git\usr\bin\sh.exe'
def ux(p):
 s=pathlib.Path(p).as_posix();return '/'+s[0].lower()+s[2:] if len(s)>2 and s[1]==':' else s
with tempfile.TemporaryDirectory(prefix='scraper-batch-test-',dir=R) as d:
 root=pathlib.Path(d);sd=root/'sd';bin=sd/'System/bin';bin.mkdir(parents=True);state=root/'state';state.mkdir()
 for name in ['MD','SFC']:
  p=sd/'Emus'/name;p.mkdir(parents=True);(p/'config.json').write_text('{}')
 (sd/'Emus/show.json').write_text('[]')
 jq=bin/'jq';jq.write_text('''#!/bin/sh
case "$*" in *rompath*) case "$*" in */MD/*) echo /Roms/MD;; *) echo /Roms/SFC;; esac;; *) echo Console;; esac
''');jq.chmod(0o755)
 sync=bin/'sync';sync.write_text('#!/bin/sh\nexit 0\n');sync.chmod(0o755)
 worker=sd/'System/usr/trimui/scripts/scraper/scrap_screenscraper.sh';worker.parent.mkdir(parents=True)
 worker.write_text('#!/bin/sh\nprintf "%s\\n" "$1" >> "'+ux(root/'systems')+'"\ntouch "'+ux(state/'cancel_all')+'"\n');worker.chmod(0o755)
 src=(R/'desenvolvimento/Apps/Scraper/Menu/° Scrape all.launch').read_text(encoding='utf8').replace('/mnt/SDCARD',ux(sd)).replace('/tmp/crossmix_scraper_progress',ux(state))
 script=root/'batch.sh';script.write_text(src,encoding='utf8');env=os.environ.copy();env['PATH']=str(bin)+os.pathsep+str(pathlib.Path(SH).parent)+os.pathsep+env['PATH']
 run=subprocess.run([SH,str(script)],env=env,capture_output=True,text=True,timeout=20)
 print('Lote exit:',run.returncode,'stderr:',run.stderr[-300:].strip());assert run.returncode==0
 systems=(root/'systems').read_text().splitlines();print('Sistemas processados antes do cancelamento:',systems);assert len(systems)==1
print('Cancelamento encerra sequencia de consoles: OK')
