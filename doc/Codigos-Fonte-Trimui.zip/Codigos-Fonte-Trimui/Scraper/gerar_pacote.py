import pathlib,zipfile,hashlib,re
r=pathlib.Path.cwd();src=r/'desenvolvimento';files=[]
for directory in ['Apps/Scraper','Emus/_Scraper','System/usr/trimui/scripts/scraper']:
 for p in sorted((src/directory).rglob('*')):
  if p.is_file() and '.sselph-scraper' not in p.parts and p.name not in ['scraper.log','Menu_cache7.db','show_json_crc.txt','current_crc_DB.txt']:
   files.append((p,p.relative_to(src).as_posix()))
files.append((r/'LEIA-ME.txt','LEIA-ME.txt'))
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+name+'\n' for p,name in files)
archive=r/'Scraper-atualizado.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p,name in files:
  info=zipfile.ZipInfo.from_file(p,'Scraper-pacote/'+name);info.create_system=3;info.compress_type=zipfile.ZIP_DEFLATED
  info.external_attr=(0o100755 if p.suffix in ['.sh','.launch'] else 0o100644)<<16
  z.writestr(info,p.read_bytes())
 z.writestr('Scraper-pacote/SHA256SUMS.txt',manifest.encode())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p,name in files:assert z.read('Scraper-pacote/'+name)==p.read_bytes()
 assert not any('scraper.json' in n or '.sselph-scraper/' in n for n in z.namelist())
h=hashlib.sha256(archive.read_bytes()).hexdigest();p=r/'instalar-scraper.sh';s=p.read_text(encoding='utf8');lines=s.splitlines();matches=[i for i,line in enumerate(lines) if 'sha256sum -c -' in line];assert len(matches)==1;i=matches[0];lines[i],n=re.subn(r'(?:ZIP_SHA256_PLACEHOLDER|[0-9a-f]{64})',h,lines[i]);assert n==1;p.write_bytes(('\n'.join(lines)+'\n').encode())
print('ZIP:',len(files),'arquivos,',archive.stat().st_size,'bytes; SHA-256:',h)
