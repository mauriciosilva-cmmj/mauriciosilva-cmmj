import pathlib,subprocess,tempfile,os,json
root=pathlib.Path.cwd();sh=r'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1123-915-0_26.1123.915.0_x64__3k8sg7r9htsxt\dependencies\native\git\usr\bin\sh.exe'
def ux(p):
 s=pathlib.Path(p).as_posix();return '/'+s[0].lower()+s[2:] if len(s)>2 and s[1]==':' else s
with tempfile.TemporaryDirectory(prefix='scraper-status-test-',dir=root) as d:
 p=pathlib.Path(d);(p/'bin').mkdir();(p/'lock').mkdir();(p/'status.json').write_text(json.dumps({'system':'MD','phase':'running','processed':4,'total':10,'percent':40,'downloaded':2,'existing':1,'failed':1}));(p/'idioma.sh').write_text('SCRAPER_PT=1\n')
 mock=p/'jq.py';mock.write_text('''import json,sys\nd=json.load(open(sys.argv[-1])); print("|".join(str(d.get(k,0)) for k in ["system","phase","processed","total","percent","downloaded","existing","failed"]))\n''')
 jq=p/'bin/jq';jq.write_text('#!/bin/sh\nexec "'+pathlib.Path(os.sys.executable).as_posix()+'" "'+mock.as_posix()+'" "$@"\n');jq.chmod(0o755)
 info=p/'info.sh';info.write_text('#!/bin/sh\nprintf "%s\\n" "$2" > "'+ux(p/'result')+'"\n');info.chmod(0o755)
 s=(root/'desenvolvimento/Apps/Scraper/Menu/! Progresso.sh').read_text(encoding='utf8').replace('/mnt/SDCARD/Apps/Scraper/idioma.sh',ux(p/'idioma.sh')).replace('/mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh',ux(info)).replace('/tmp/crossmix_scraper_progress',ux(p))
 (p/'status.sh').write_text(s,encoding='utf8');(p/'run.sh').write_text('#!/bin/sh\nprintf "%s\\n" "$$" > "'+ux(p/'lock/pid')+'"\nsh "'+ux(p/'status.sh')+'"\n')
 env=os.environ.copy();env['PATH']=str(p/'bin')+os.pathsep+str(pathlib.Path(sh).parent)+os.pathsep+env['PATH']
 run=subprocess.run([sh,str(p/'run.sh')],env=env,capture_output=True,text=True,timeout=20);assert run.returncode==0,run.stderr
 text=(p/'result').read_text();print(text.strip());assert all(x in text for x in ['MD','4/10 - 40%','Baixadas: 2','Existentes: 1','Falhas: 1','Consultando'])
print('Tela de progresso e snapshot atomico: OK')
