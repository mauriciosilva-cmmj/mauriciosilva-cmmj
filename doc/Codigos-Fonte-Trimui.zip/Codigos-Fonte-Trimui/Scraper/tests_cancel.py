import pathlib,subprocess,tempfile,os
root=pathlib.Path.cwd();sh=r'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1123-915-0_26.1123.915.0_x64__3k8sg7r9htsxt\dependencies\native\git\usr\bin\sh.exe'
def posix(p):
 s=pathlib.Path(p).as_posix();return '/'+s[0].lower()+s[2:] if len(s)>2 and s[1]==':' else s
with tempfile.TemporaryDirectory(prefix='scraper-cancel-test-',dir=root) as d:
 p=pathlib.Path(d);(p/'lock').mkdir(); (p/'idioma.sh').write_text('SCRAPER_PT=1\n');(p/'infoscreen.sh').write_text('#!/bin/sh\nprintf "%s\\n" "$2" > "'+posix(p/'notice')+'"\n')
 source=(root/'desenvolvimento/Apps/Scraper/Menu/! Cancelar.sh').read_text(encoding='utf8').replace('/tmp/crossmix_scraper_progress',posix(p)).replace('/mnt/SDCARD/Apps/Scraper/idioma.sh',posix(p/'idioma.sh')).replace('/mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh',posix(p/'infoscreen.sh'))
 (p/'cancel.sh').write_text(source);script='''#!/bin/sh
PATH=/usr/bin:$PATH
printf '%s\\n' "$$" > "'''+posix(p/'lock/pid')+'''"
sh "'''+posix(p/'cancel.sh')+'''"
''';(p/'test.sh').write_text(script)
 # Source paths are under a task-owned temporary directory only.
 (p/'infoscreen.sh').chmod(0o755)
 r=subprocess.run([sh,str(p/'test.sh')],capture_output=True,text=True);print('Exit:',r.returncode,'stderr:',r.stderr.strip())
 assert r.returncode==0 and (p/'cancel_all').exists(); print('Cancelamento cooperativo sinalizado: OK')
