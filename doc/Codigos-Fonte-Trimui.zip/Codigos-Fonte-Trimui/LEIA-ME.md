# Códigos-fonte dos aplicativos Trimui

Este pacote reúne as versões modificadas, separadas em `FileManager/` e `Scraper/`. Cada pasta contém instruções próprias. A estrutura foi preservada para facilitar desenvolvimento e geração dos pacotes de instalação.

O arquivo `SHA256SUMS.txt` permite verificar a integridade dos arquivos deste pacote. Os arquivos de instalação gerados anteriormente são distribuições separadas: este ZIP contém fontes e recursos, não é o ZIP de instalação.

As bibliotecas compiladas SDL incluídas no FileManager são dependências de compilação, identificadas no README do aplicativo. O compilador Zig não está incluído. Configurações pessoais, credenciais, registros e ROMs não foram incluídos intencionalmente.

Não foi possível validar o funcionamento no console físico. Em particular, a exibição do indicador do Scraper sobre outros aplicativos depende do suporte do firmware e precisa de teste no aparelho.
