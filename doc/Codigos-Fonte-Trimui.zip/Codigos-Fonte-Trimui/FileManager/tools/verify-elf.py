import pathlib,sys,json
r=pathlib.Path(__file__).resolve().parent.parent;sys.path.insert(0,str(r/'tools/elftools'))
from elftools.elf.elffile import ELFFile
for filename in ['backup-original/DinguxCommander','build/trimui/DinguxCommander']:
    with (r/filename).open('rb') as f:
        e=ELFFile(f); d=e.get_section_by_name('.dynamic'); deps=[t.needed for t in d.iter_tags() if t.entry.d_tag=='DT_NEEDED']; versions=[]
        v=e.get_section_by_name('.gnu.version_r')
        if v:
            for ver,aux in v.iter_versions():versions += [a.name for a in aux]
        print(filename,e.header['e_machine'],[p.get_interp_name() for p in e.iter_segments() if p.header.p_type=='PT_INTERP']);print('NEEDED',deps);print('VERSIONS',versions)
        if filename.startswith('build'):
            assert e.header['e_machine']=='EM_AARCH64'
            assert all(tuple(map(int,x.removeprefix('GLIBC_').split('.'))) <= (2,17) for x in versions if x.startswith('GLIBC_'))
            assert not any(x in dep for dep in deps for x in ['libc++','libstdc++','libgcc_s'])
            imports=[s.name for s in e.get_section_by_name('.dynsym').iter_symbols() if s.entry.st_shndx=='SHN_UNDEF' and s.name.startswith(('SDL_','TTF_','IMG_','zoomSurface','shrinkSurface'))]
            available=set()
            for lib in list((r/'tools/sdk').glob('*.so.*'))+list((r/'lib').glob('*.so.*')):
                with lib.open('rb') as lf:
                    le=ELFFile(lf); section=le.get_section_by_name('.dynsym')
                    if section:available.update(s.name for s in section.iter_symbols() if s.entry.st_shndx!='SHN_UNDEF')
            missing=set(imports)-available;print('Missing SDL SDK symbols:',sorted(missing));assert not missing
print('ELF compatibility checks passed')
