import pathlib, subprocess
root=pathlib.Path(__file__).resolve().parent.parent
zig=root/'tools/python-zig/ziglang/zig.exe'
build=root/'build'; build.mkdir(exist_ok=True)
flags=['-O2','-DMINIZ_NO_ARCHIVE_WRITING_APIS','-DMINIZ_NO_ZLIB_APIS','-DMINIZ_NO_ZLIB_COMPATIBLE_NAMES']
objects=[]
for name in ['miniz','miniz_tinfl','miniz_zip']:
    obj=build/(name+'.obj'); objects.append(str(obj))
    subprocess.run([str(zig),'cc',*flags,'-c',str(root/'source/third_party/miniz'/f'{name}.c'),'-o',str(obj)],check=True)
subprocess.run([str(zig),'c++',*flags,'-std=c++17','-Isource','source/file_operations.cpp','source/tests/operations_driver.cpp',*objects,'-o',str(build/'operations-test.exe')],cwd=root,check=True)
