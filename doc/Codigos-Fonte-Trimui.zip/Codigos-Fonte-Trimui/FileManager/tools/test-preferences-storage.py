from pathlib import Path
import subprocess,tempfile,sys
r=Path(__file__).resolve().parent.parent;z=r/'tools/python-zig/ziglang/zig.exe'
subprocess.run([str(z),'c++','-std=c++17','-O2','-Isource','source/tests/preferences_storage_test.cpp','source/user_preferences.cpp','source/storage_info.cpp','-o','build/preferences-storage-test.exe'],cwd=r,check=True)
if '--compile-only' in sys.argv:
    print('Preferences/storage tests compiled; execution skipped by request')
    raise SystemExit(0)
with tempfile.TemporaryDirectory(prefix='prefs-test-',dir=r/'build') as directory:
    assert Path(directory).resolve().is_relative_to((r/'build').resolve())
    subprocess.run([str(r/'build/preferences-storage-test.exe'),directory],cwd=r,check=True)
