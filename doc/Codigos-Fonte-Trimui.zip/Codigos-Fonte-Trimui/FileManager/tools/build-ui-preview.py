import pathlib,subprocess,os
r=pathlib.Path(__file__).resolve().parent.parent
z=r/'tools/python-zig/ziglang/zig.exe'; dll=r/'tools/sdl-windows/sdl2dll/dll'
flags=['-O2','-std=c++17','-DUSE_SDL2','-DMINIZ_NO_ARCHIVE_WRITING_APIS','-DMINIZ_NO_ZLIB_APIS','-DMINIZ_NO_ZLIB_COMPATIBLE_NAMES','-Isource','-Itools/SDL2','-Itools/sdk']
files=['source/tests/ui_preview.cpp','source/dialog.cpp','source/sdl_ttf_multifont.cpp','source/controller_buttons.cpp','source/file_operations.cpp']
objects=[str(r/'build'/f'{name}.obj') for name in ['miniz','miniz_tinfl','miniz_zip']]
subprocess.run([str(z),'c++',*flags,*files,*objects,str(dll/'SDL2.dll'),str(dll/'SDL2_ttf.dll'),'-o','build/ui-preview.exe'],cwd=r,check=True)
env=os.environ.copy();env['PATH']=str(dll)+os.pathsep+env['PATH']
subprocess.run([str(r/'build/ui-preview.exe')],cwd=r,env=env,check=True)
