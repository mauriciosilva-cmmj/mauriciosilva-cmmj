import pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent.parent; src=root/'source'; out=root/'build/trimui'; out.mkdir(parents=True,exist_ok=True)
zig=root/'tools/python-zig/ziglang/zig.exe'; sdk=root/'tools/sdk'
flags=['-target','aarch64-linux-gnu.2.17','-O2','-fno-sanitize=all','-DMINIZ_NO_ARCHIVE_WRITING_APIS','-DMINIZ_NO_ZLIB_APIS','-DMINIZ_NO_ZLIB_COMPATIBLE_NAMES','-DUSE_SDL2','-Isource','-Itools/SDL2','-Itools/sdk','-Isource/third_party/SDL2_ttf','-Isource/third_party/SDL2_gfx-1.0.4']
headers=list(src.glob('*.h'))+list((root/'tools/SDL2').glob('*.h'))+list((root/'tools/sdk').glob('*.h'))
header_time=max(p.stat().st_mtime for p in headers)
objects=[]
files=sorted(src.glob('*.cpp'))+list((src/'third_party/miniz').glob('*.c'))
for p in files:
    obj=out/(p.stem+'.o'); objects.append(str(obj))
    if obj.exists() and obj.stat().st_mtime>max(p.stat().st_mtime,header_time):continue
    print('Compiling',p.name,flush=True)
    subprocess.run([str(zig),'c++' if p.suffix=='.cpp' else 'cc',*flags,*(['-std=c++17'] if p.suffix=='.cpp' else []),'-c',str(p),'-o',str(obj)],cwd=root,check=True)
libs=['libSDL2-2.0.so.0','libSDL2_ttf-2.0.so.0']
paths=[]
for lib in libs:
    matches=list(sdk.glob(lib+'*'))
    if not matches:raise SystemExit('Missing SDK library: '+lib)
    paths.append(str(matches[0]))
paths += [str(root/'lib/libSDL2_image-2.0.so.0'),str(root/'lib/libSDL2_gfx-1.0.so.0')]
subprocess.run([str(zig),'c++',*flags,*objects,*paths,'-Wl,--allow-shlib-undefined','-s','-o',str(out/'DinguxCommander')],cwd=root,check=True)
print('Built',out/'DinguxCommander',flush=True)
