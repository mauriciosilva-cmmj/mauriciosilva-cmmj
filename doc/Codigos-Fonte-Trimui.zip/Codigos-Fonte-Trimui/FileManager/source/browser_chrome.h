#pragma once
#include "sdl_ptrs.h"
#include "storage_info.h"
#include <vector>

class BrowserChrome {
private:
    std::vector<StorageInfo::Volume> volumes_;
    Uint32 lastRefresh_ = 0;
    bool initialized_ = false;
    mutable SDLSurfaceUniquePtr legend_;
public:
    bool refresh(bool force = false);
    void invalidate() { legend_.reset(); }
    void render() const;
    void renderContext(const std::string &parent, const std::string &name, bool directory) const;
    void renderShortcut(const std::string &label, const std::string &path) const;
    void showDisks() const;
};
