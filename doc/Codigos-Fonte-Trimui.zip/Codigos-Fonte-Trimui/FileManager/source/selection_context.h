#pragma once
#include <string>
struct SelectionContext {
    std::string title, detail, path;
    bool directory = false;
};
SelectionContext describeSelection(const std::string &parent, const std::string &name, bool directory);
