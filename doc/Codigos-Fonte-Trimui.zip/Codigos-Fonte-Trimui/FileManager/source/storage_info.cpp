#include "storage_info.h"
#include <algorithm>
#include <array>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <set>
#include <sstream>
#ifndef _WIN32
#include <sys/statvfs.h>
#endif

namespace StorageInfo {
namespace {
std::string unescape(const std::string &value) {
    std::string out;
    for (std::size_t i = 0; i < value.size(); ++i) {
        if (value[i] == '\\' && i + 3 < value.size()
            && value[i+1] >= '0' && value[i+1] <= '7'
            && value[i+2] >= '0' && value[i+2] <= '7'
            && value[i+3] >= '0' && value[i+3] <= '7') {
            out += static_cast<char>((value[i+1]-'0')*64 + (value[i+2]-'0')*8 + value[i+3]-'0'); i += 3;
        } else out += value[i];
    }
    return out;
}
bool starts(const std::string &s, const std::string &prefix) { return s.compare(0, prefix.size(), prefix) == 0; }
bool at(const std::string &s, const std::string &parent) { return s == parent || starts(s, parent + "/"); }
std::string basename(const std::string &p) { const auto pos = p.rfind('/'); return p.substr(pos == std::string::npos ? 0 : pos + 1); }
std::string label(const std::string &device) {
    namespace fs = std::filesystem;
    std::error_code ec;
    auto canonical = fs::canonical(device, ec);
    if (ec) return {};
    fs::directory_iterator it("/dev/disk/by-label", ec), end;
    while (!ec && it != end) {
        std::error_code linkError;
        if (fs::canonical(it->path(), linkError) == canonical && !linkError) return it->path().filename().u8string();
        it.increment(ec);
    }
    // Trimui firmware may omit /dev/disk/by-label. Read only the FAT boot
    // sector label as a fallback; do not run blkid or write to the device.
    std::ifstream input(device, std::ios::binary);
    std::array<char,512> boot{};
    if (!input.read(boot.data(), boot.size()) || static_cast<unsigned char>(boot[510]) != 0x55
        || static_cast<unsigned char>(boot[511]) != 0xaa) return {};
    int offset = 0;
    if (std::string(boot.data()+82, 5) == "FAT32") offset = 71;
    else if (std::string(boot.data()+54, 3) == "FAT") offset = 43;
    if (!offset) return {};
    std::string name(boot.data()+offset,11);
    while (!name.empty() && name.back() == ' ') name.pop_back();
    if (name == "NO NAME") return {};
    for (auto c : name) if (static_cast<unsigned char>(c) < 32 || static_cast<unsigned char>(c) > 126) return {};
    return name;
}
}

std::vector<Volume> parseMounts(std::istream &input) {
    std::vector<Volume> volumes;
    std::set<std::string> seen;
    std::string line;
    Volume root{Kind::Internal, "", "/", "Sistema"};
    bool haveRoot = false, haveInternal = false;
    while (std::getline(input, line)) {
        std::istringstream fields(line);
        std::string device, mount, type, options;
        if (!(fields >> device >> mount >> type >> options)) continue;
        device = unescape(device); mount = unescape(mount);
        if (type == "tmpfs" || type == "devtmpfs" || type == "proc" || type == "sysfs" || starts(device,"/dev/loop")) continue;
        if (mount == "/") {
            if (starts(device,"/dev/") || type == "overlay" || type == "overlayfs") {
                root.device = device; root.readOnly = starts(options,"ro,") || options == "ro"; haveRoot = true;
            }
            continue;
        }
        if (at(mount,"/proc") || at(mount,"/sys") || at(mount,"/dev") || at(mount,"/run")) continue;
        Kind kind;
        if (at(mount,"/mnt/SDCARD") || starts(device,"/dev/mmcblk1")) kind = Kind::SdCard;
        else if (starts(device,"/dev/sd") || at(mount,"/mnt/USB") || at(mount,"/media") || starts(mount,"/mnt/usb")) kind = Kind::Usb;
        else if (starts(device,"/dev/mmcblk0") || at(mount,"/mnt/UDISK")) { kind = Kind::Internal; haveInternal = true; }
        else continue;
        // Ignore bind mounts of an already listed partition.
        if (!seen.insert(device).second) continue;
        volumes.push_back({kind,device,mount,basename(mount),0,0,false, starts(options,"ro,") || options == "ro"});
    }
    if (!haveInternal && haveRoot) volumes.push_back(root);
    std::stable_sort(volumes.begin(),volumes.end(),[](const Volume &a,const Volume &b) { return a.kind < b.kind; });
    return volumes;
}

std::vector<Volume> connected() {
    std::ifstream mounts("/proc/self/mounts");
    if (!mounts) mounts.open("/proc/mounts");
    auto volumes = parseMounts(mounts);
    for (auto &volume : volumes) {
        auto name = label(volume.device);
        if (!name.empty()) volume.name = name;
#ifndef _WIN32
        struct statvfs data{};
        if (::statvfs(volume.mount.c_str(), &data) == 0 && data.f_blocks && data.f_frsize) {
            volume.total = static_cast<std::uint64_t>(data.f_blocks) * data.f_frsize;
            volume.free = static_cast<std::uint64_t>(data.f_bavail) * data.f_frsize;
            volume.capacityKnown = true;
        }
#endif
    }
    return volumes;
}

std::string kindName(Kind kind) { return kind == Kind::SdCard ? "SDCARD" : kind == Kind::Usb ? "Pendrive" : "Memoria interna"; }
std::string formatBytes(std::uint64_t bytes) {
    static const char *units[] = {"B","KiB","MiB","GiB","TiB"};
    double value = bytes; unsigned i = 0;
    while (value >= 1024 && i < 4) { value /= 1024; ++i; }
    char text[48]; std::snprintf(text,sizeof(text),"%.1f %s",value,units[i]); return text;
}
std::string description(const Volume &v) {
    return kindName(v.kind) + " [" + v.name + "]  " + (v.capacityKnown ? formatBytes(v.free) + " / " + formatBytes(v.total) : "espaco indisponivel")
        + (v.readOnly ? " (somente leitura)" : "");
}
}
