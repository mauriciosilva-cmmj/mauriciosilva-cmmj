#include "user_preferences.h"
#include <algorithm>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>
#ifdef _WIN32
#include <io.h>
#include <process.h>
#include <windows.h>
#else
#include <unistd.h>
#endif

UserPreferences UserPreferences::load(const std::string &path) {
    UserPreferences result;
    std::ifstream input(path);
    std::string line;
    while (std::getline(input, line)) {
        const auto pos = line.find('=');
        if (pos == std::string::npos) continue;
        const auto key = line.substr(0, pos);
        std::istringstream value(line.substr(pos + 1));
        int number; std::string extra;
        if (!(value >> number) || value >> extra) continue;
        if (key == "font_size") result.fontSize = std::clamp(number, minFontSize, maxFontSize);
        if (key == "compact_layout" && (number == 0 || number == 1)) result.compactLayout = number != 0;
        if (key == "shortcut_panel" && number >= 0 && number <= 2) result.shortcutPanel = number;
        if (key == "show_quick_access" && (number == 0 || number == 1)) result.quickAccess = number != 0;
        if (key == "friendly_names" && (number == 0 || number == 1)) result.friendlyNames = number != 0;
        if (key == "show_context" && (number == 0 || number == 1)) result.context = number != 0;
        if (key == "show_button_legend" && (number == 0 || number == 1)) result.buttonLegend = number != 0;
    }
    return result;
}

bool UserPreferences::save(const std::string &path, std::string &error) const {
    error.clear();
    // Preserve settings unknown to this version when migrating existing files.
    std::string retained;
    {
        std::ifstream existing(path, std::ios::binary);
        std::string line;
        while (std::getline(existing, line)) {
            if (retained.size() + line.size() > 65536) {
                error = "Arquivo de configuracoes muito grande"; return false;
            }
            const auto pos = line.find('=');
            const auto key = line.substr(0,pos);
            if (key == "font_size" || key == "show_button_legend" || key == "show_context" || key == "show_quick_access" || key == "friendly_names" || key == "compact_layout" || key == "shortcut_panel") continue;
            retained += line + '\n';
        }
        if (existing.bad()) { error = "Erro ao ler configuracoes"; return false; }
    }
    const std::string temporary = path + ".tmp-" + std::to_string(
#ifdef _WIN32
        _getpid()
#else
        getpid()
#endif
    );
    FILE *file = std::fopen(temporary.c_str(), "wbx");
    if (!file) { error = std::strerror(errno); return false; }
    bool ok = std::fprintf(file, "font_size=%d\nshow_button_legend=%d\nshow_context=%d\nshow_quick_access=%d\nfriendly_names=%d\ncompact_layout=%d\nshortcut_panel=%d\n",
        std::clamp(fontSize, minFontSize, maxFontSize), buttonLegend ? 1 : 0, context ? 1 : 0, quickAccess ? 1 : 0, friendlyNames ? 1 : 0, compactLayout ? 1 : 0, std::clamp(shortcutPanel,0,2)) > 0;
    if (!retained.empty()) ok = std::fwrite(retained.data(),1,retained.size(),file)==retained.size() && ok;
    ok = std::fflush(file) == 0 && ok;
#ifdef _WIN32
    ok = _commit(_fileno(file)) == 0 && ok;
#else
    ok = ::fsync(::fileno(file)) == 0 && ok;
#endif
    ok = std::fclose(file) == 0 && ok;
    if (ok) {
#ifdef _WIN32
        ok = MoveFileExA(temporary.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) != 0;
#else
        ok = std::rename(temporary.c_str(), path.c_str()) == 0;
#endif
    }
    if (!ok) { error = "Nao foi possivel salvar " + path; std::remove(temporary.c_str()); }
    return ok;
}
