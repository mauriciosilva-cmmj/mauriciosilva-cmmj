#include "file_operations.h"
#include "third_party/miniz/miniz.h"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <limits>
#include <memory>
#include <stdexcept>
#include <fcntl.h>
#include <sys/stat.h>
#ifdef _WIN32
#include <io.h>
#include <process.h>
#include <windows.h>
#else
#include <unistd.h>
#endif

namespace FileOperations {
namespace {
namespace fs = std::filesystem;
struct Cancelled {};
struct Context {
    const Callbacks &callbacks;
    Progress state;
    bool all = false;
    std::uint64_t skipped = 0;
    void update(const fs::path &path) {
        state.path = path.u8string();
        if (callbacks.progress && !callbacks.progress(state)) throw Cancelled{};
    }
    void add(std::uint64_t size) {
        if (size >= std::numeric_limits<std::uint64_t>::max() - state.total)
            throw std::runtime_error("Operation is too large");
        state.total += size + 1; // One unit also for empty files/directories.
        ++state.itemTotal;
    }
    bool overwrite(const fs::path &path) {
        if (all) return true;
        auto answer = callbacks.overwrite ? callbacks.overwrite(path.u8string()) : Decision::Cancel;
        if (answer == Decision::Cancel) throw Cancelled{};
        if (answer == Decision::Skip) { ++skipped; return false; }
        all = answer == Decision::All;
        return true;
    }
    void finish(const fs::path &path, std::uint64_t bytes = 0) {
        state.done += bytes + 1;
        ++state.items;
        update(path);
    }
};

bool pathExists(const fs::path &p) {
    return fs::symlink_status(p).type() != fs::file_type::not_found;
}
bool within(const fs::path &child, const fs::path &parent) {
    auto a = child.begin(), b = parent.begin();
    for (; b != parent.end(); ++a, ++b)
        if (a == child.end() || *a != *b) return false;
    return true;
}
fs::path normalized(const fs::path &p) { return fs::weakly_canonical(fs::absolute(p)); }
void checkDestination(const fs::path &p) {
    // Never follow a pre-existing link while writing an extracted/copied tree.
    fs::path current;
    for (const auto &part : fs::absolute(p).lexically_normal()) {
        current /= part;
        if (fs::is_symlink(fs::symlink_status(current)))
            throw std::runtime_error("Destination contains a symbolic link: " + current.u8string());
    }
}

struct Entry { fs::path source, target; std::uint64_t size; bool directory, link; };
void scan(const fs::path &src, const fs::path &dst, std::vector<Entry> &entries,
    Context &ctx, bool remove) {
    ctx.update(src);
    const auto status = fs::symlink_status(src);
    const bool dir = fs::is_directory(status), link = fs::is_symlink(status);
    if (!dir && !link && !fs::is_regular_file(status))
        throw std::runtime_error("Unsupported file: " + src.u8string());
    const auto size = remove || dir || link ? 0 : fs::file_size(src);
    entries.push_back({src, dst, size, dir, link});
    ctx.add(size);
    if (dir) for (const auto &child : fs::directory_iterator(src))
        scan(child.path(), dst / child.path().filename(), entries, ctx, remove);
}

// A replacement is committed only after the entire file is written and synced.
// On failure/cancel, keep the original destination and clean only our temp file.
class PendingFile {
    fs::path temporary, target;
    int fd = -1;
public:
    explicit PendingFile(const fs::path &p) : target(p) {
        static unsigned sequence = 0;
        for (unsigned i = 0; i != 1000; ++i) {
            temporary = p.parent_path() / (".commander-" + std::to_string(
#ifdef _WIN32
                _getpid()
#else
                getpid()
#endif
                ) + "-" + std::to_string(++sequence) + ".tmp");
#ifdef _WIN32
            fd = _wopen(temporary.c_str(), _O_WRONLY | _O_CREAT | _O_EXCL | _O_BINARY, _S_IREAD | _S_IWRITE);
#else
            fd = ::open(temporary.c_str(), O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0666);
#endif
            if (fd >= 0) return;
            if (errno != EEXIST) break;
        }
        throw std::runtime_error("Cannot create output in " + p.parent_path().u8string() + ": " + std::strerror(errno));
    }
    ~PendingFile() {
        if (fd >= 0) {
#ifdef _WIN32
            _close(fd);
#else
            ::close(fd);
#endif
        }
        std::error_code ignored;
        if (!temporary.empty()) fs::remove(temporary, ignored);
    }
    void write(const void *data, std::size_t size) {
        auto p = static_cast<const char *>(data);
        while (size) {
#ifdef _WIN32
            const auto n = _write(fd, p, static_cast<unsigned>(size));
#else
            const auto n = ::write(fd, p, size);
#endif
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) throw std::runtime_error("Write failed: " + std::string(std::strerror(errno)));
            p += n; size -= n;
        }
    }
    void commit() {
#ifdef _WIN32
        if (_commit(fd) != 0) throw std::runtime_error("Cannot sync output file");
        const int closed = _close(fd); fd = -1;
        if (closed != 0 || !MoveFileExW(temporary.c_str(), target.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
            throw std::runtime_error("Cannot replace " + target.u8string());
#else
        if (::fsync(fd) != 0) throw std::runtime_error("Cannot sync output: " + std::string(std::strerror(errno)));
        const int closed = ::close(fd); fd = -1;
        if (closed != 0 || ::rename(temporary.c_str(), target.c_str()) != 0)
            throw std::runtime_error("Cannot replace " + target.u8string() + ": " + std::strerror(errno));
#endif
        temporary.clear();
    }
};

void copy(const Entry &e, Context &ctx) {
    std::unique_ptr<FILE, int(*)(FILE *)> in(std::fopen(e.source.u8string().c_str(), "rb"), std::fclose);
    if (!in) throw std::runtime_error("Cannot read " + e.source.u8string());
    PendingFile output(e.target);
    std::array<char, 256 * 1024> buffer;
    std::uint64_t copied = 0;
    for (;;) {
        ctx.update(e.source);
        const auto count = std::fread(buffer.data(), 1, buffer.size(), in.get());
        if (count) { output.write(buffer.data(), count); ctx.state.done += count; copied += count; }
        if (count < buffer.size()) {
            if (std::ferror(in.get())) throw std::runtime_error("Read failed: " + e.source.u8string());
            break;
        }
    }
    if (copied != e.size) throw std::runtime_error("Source changed during copy: " + e.source.u8string());
    // Preserve executable/read permissions when supported (e.g. ext4).
    std::error_code ignored;
    // Temp files use the destination filesystem's default permissions on FAT.
    output.commit();
    fs::permissions(e.target, fs::status(e.source).permissions(), ignored);
    ctx.finish(e.source);
}

void transfer(Kind kind, const std::vector<Entry> &entries, Context &ctx) {
    for (const auto &e : entries) {
        ctx.update(e.source);
        checkDestination(e.target);
        if (e.directory) {
            if (pathExists(e.target) && !fs::is_directory(e.target))
                throw std::runtime_error("Destination is not a directory: " + e.target.u8string());
            fs::create_directory(e.target);
            ctx.finish(e.source);
            continue;
        }
        if (pathExists(e.target)) {
            if (fs::is_directory(e.target)) throw std::runtime_error("Destination is a directory: " + e.target.u8string());
            if (fs::equivalent(e.source, e.target)) throw std::runtime_error("Source and destination are the same file");
            if (!ctx.overwrite(e.target)) { ctx.finish(e.source, e.size); continue; }
        }
        if (kind == Kind::Move) {
            std::error_code ec;
            fs::rename(e.source, e.target, ec);
            if (!ec) { ctx.finish(e.source, e.size); continue; }
            if (ec != std::errc::cross_device_link
#ifdef _WIN32
                && ec != std::errc::file_exists && ec != std::errc::permission_denied
#endif
                ) throw fs::filesystem_error("Move failed", e.source, e.target, ec);
        }
        if (e.link) {
            if (pathExists(e.target)) fs::remove(e.target);
            fs::copy_symlink(e.source, e.target);
            ctx.finish(e.source);
        } else copy(e, ctx);
        // Never remove a source until its destination has been committed.
        if (kind == Kind::Move) fs::remove(e.source);
    }
    if (kind == Kind::Move) for (auto i = entries.rbegin(); i != entries.rend(); ++i)
        if (i->directory && fs::is_empty(i->source)) fs::remove(i->source);
}

struct Zip {
    mz_zip_archive archive{};
    explicit Zip(const std::string &p) {
        if (!mz_zip_reader_init_file(&archive, p.c_str(), 0))
            throw std::runtime_error("Cannot open ZIP: " + p);
    }
    ~Zip() { mz_zip_reader_end(&archive); }
};
fs::path zipPath(Zip &zip, mz_uint index) {
    const auto length = mz_zip_reader_get_filename(&zip.archive, index, nullptr, 0);
    if (length < 2) throw std::runtime_error("ZIP contains an empty filename");
    std::string name(length, '\0');
    if (mz_zip_reader_get_filename(&zip.archive, index, &name[0], length) != length)
        throw std::runtime_error("Cannot read ZIP filename");
    name.pop_back();
    std::replace(name.begin(), name.end(), '\\', '/');
    if (name[0] == '/' || name.find(':') != std::string::npos || name.find('\0') != std::string::npos)
        throw std::runtime_error("Unsafe ZIP path: " + name);
    fs::path path = fs::u8path(name);
    for (const auto &part : path) if (part == "..") throw std::runtime_error("Unsafe ZIP path: " + name);
    path = path.lexically_normal();
    if (path.empty() || path == ".") throw std::runtime_error("Unsafe ZIP path: " + name);
    return path;
}
struct ZipEntry { mz_uint archive, index; fs::path target; std::uint64_t size; bool directory; };
struct ZipOutput {
    PendingFile &output; Context &ctx; fs::path path;
    std::uint64_t written = 0;
    std::uint64_t limit = 0;
    std::exception_ptr error;
};
size_t zipWrite(void *opaque, mz_uint64 offset, const void *data, size_t size) {
    auto &out = *static_cast<ZipOutput *>(opaque);
    try {
        out.ctx.update(out.path);
        if (offset != out.written) throw std::runtime_error("Unexpected ZIP offset");
        if (size > out.limit - out.written) throw std::runtime_error("ZIP exceeds declared size");
        out.output.write(data, size);
        out.written += size; out.ctx.state.done += size;
        return size;
    } catch (...) { out.error = std::current_exception(); return 0; }
}
void extract(const std::vector<std::string> &sources, const fs::path &dest, Context &ctx) {
    std::vector<std::unique_ptr<Zip>> archives;
    std::vector<ZipEntry> entries;
    // Validate every archive and path before making any changes.
    for (const auto &source : sources) {
        ctx.update(fs::u8path(source));
        archives.emplace_back(new Zip(source));
        auto &zip = *archives.back();
        if (mz_zip_reader_get_num_files(&zip.archive) > 100000 || entries.size() + mz_zip_reader_get_num_files(&zip.archive) > 100000)
            throw std::runtime_error("ZIP has too many entries (limit 100000)");
        for (mz_uint i = 0; i < mz_zip_reader_get_num_files(&zip.archive); ++i) {
            mz_zip_archive_file_stat info;
            if (!mz_zip_reader_file_stat(&zip.archive, i, &info)) throw std::runtime_error("Invalid ZIP entry");
            auto path = dest / zipPath(zip, i);
            ctx.update(path);
            const auto type = (info.m_external_attr >> 16) & 0170000;
            if (type && type != 0100000 && type != 0040000)
                throw std::runtime_error("ZIP links/special files are not supported: " + path.u8string());
            if (info.m_is_encrypted || !info.m_is_supported)
                throw std::runtime_error("Encrypted or unsupported ZIP entry: " + path.u8string());
            checkDestination(path);
            // An archive must never overwrite itself or another selected ZIP.
            for (const auto &input : sources)
                if (normalized(path) == normalized(fs::u8path(input)))
                    throw std::runtime_error("ZIP would overwrite a selected archive");
            entries.push_back({static_cast<mz_uint>(archives.size()-1), i, path,
                info.m_is_directory ? 0 : info.m_uncomp_size, info.m_is_directory != 0});
            ctx.add(entries.back().size);
        }
    }
    std::error_code spaceError;
    const auto space = fs::space(dest, spaceError);
    if (!spaceError && ctx.state.total - ctx.state.itemTotal > space.available)
        throw std::runtime_error("Not enough free space for ZIP contents");
    ctx.state.phase = "Extracting";
    for (const auto &e : entries) {
        ctx.update(e.target);
        checkDestination(e.target);
        if (e.directory) {
            fs::create_directories(e.target);
            ctx.finish(e.target);
            continue;
        }
        fs::create_directories(e.target.parent_path());
        if (pathExists(e.target)) {
            if (fs::is_directory(e.target)) throw std::runtime_error("Destination is a directory: " + e.target.u8string());
            if (!ctx.overwrite(e.target)) { ctx.finish(e.target, e.size); continue; }
        }
        PendingFile output(e.target);
        ZipOutput out{output, ctx, e.target, 0, e.size};
        const bool ok = mz_zip_reader_extract_to_callback(&archives[e.archive]->archive, e.index, zipWrite, &out, 0);
        if (out.error) std::rethrow_exception(out.error);
        if (!ok || out.written != e.size) throw std::runtime_error("ZIP is damaged or cannot be read: " + e.target.u8string());
        output.commit();
        ctx.finish(e.target);
    }
}
}

Result run(Kind kind, const std::vector<std::string> &sources,
    const std::string &destination, const Callbacks &callbacks) {
    Context ctx{callbacks};
    Result result;
    try {
        ctx.state.phase = "Preparing";
        ctx.update({});
        fs::path dest;
        if (kind != Kind::Remove) {
            dest = normalized(fs::u8path(destination));
            if (!fs::is_directory(dest)) throw std::runtime_error("Destination directory does not exist");
        }
        if (kind == Kind::Extract) extract(sources, dest, ctx);
        else {
            std::vector<Entry> entries;
            std::vector<fs::path> roots;
            for (const auto &source : sources) {
                // Canonicalize the parent only: selected symlinks remain links.
                const auto raw = fs::absolute(fs::u8path(source)).lexically_normal();
                const auto src = normalized(raw.parent_path()) / raw.filename();
                if (src == src.root_path() || raw.filename().empty())
                    throw std::runtime_error("Cannot operate on the filesystem root");
                for (const auto &root : roots)
                    if (within(src, root) || within(root, src))
                        throw std::runtime_error("Selection contains overlapping paths");
                roots.push_back(src);
                auto target = dest / src.filename();
                if (kind != Kind::Remove && within(normalized(target), src))
                    throw std::runtime_error("Destination is the source or inside it");
                scan(src, target, entries, ctx, kind == Kind::Remove);
            }
            ctx.state.phase = kind == Kind::Copy ? "Copying" : kind == Kind::Move ? "Moving" : "Deleting";
            if (kind == Kind::Remove) {
                for (auto i = entries.rbegin(); i != entries.rend(); ++i) {
                    ctx.update(i->source);
                    if (!fs::remove(i->source)) throw std::runtime_error("Cannot delete " + i->source.u8string());
                    ctx.finish(i->source);
                }
            } else transfer(kind, entries, ctx);
        }
        ctx.state.complete = true;
        ctx.state.done = ctx.state.total;
        ctx.update({});
    } catch (const Cancelled &) { result.cancelled = true; }
      catch (const std::exception &e) { result.error = e.what(); }
    result.skipped = ctx.skipped;
    return result;
}
}
