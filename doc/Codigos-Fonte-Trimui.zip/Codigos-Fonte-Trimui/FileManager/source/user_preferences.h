#pragma once
#include <string>

struct UserPreferences {
    int fontSize = 10;
    bool buttonLegend = true;
    bool context = true;
    bool quickAccess = true;
    bool friendlyNames = true;
    bool compactLayout = false;
    int shortcutPanel = 0;
    static constexpr int minFontSize = 8, maxFontSize = 24;
    static UserPreferences load(const std::string &path);
    bool save(const std::string &path, std::string &error) const;
};
