#include "settings_menu.h"
#include "config.h"
#include "dialog.h"
#include "error_dialog.h"
#include "user_preferences.h"

bool OpenSettingsMenu() {
    UserPreferences pending{config().font_size,config().show_button_legend,config().show_context,config().show_quick_access,config().friendly_names,config().compact_layout,config().shortcut_panel};
    for (;;) {
        int result;
        {
            CDialog dialog("Configuracoes");
            dialog.addOption("Tamanho da fonte: "+std::to_string(pending.fontSize));
            dialog.addOption(std::string("Legenda dos botoes: ")+(pending.buttonLegend?"Mostrar":"Ocultar"));
            dialog.addOption(std::string("Faixa contextual: ")+(pending.context?"Mostrar":"Ocultar"));
            dialog.addOption(std::string("Acesso rapido: ")+(pending.quickAccess?"Mostrar":"Ocultar"));
            dialog.addOption(std::string("Nomes amigaveis: ")+(pending.friendlyNames?"Mostrar":"Ocultar"));
            dialog.addOption("Layout e navegacao...");
            dialog.addOption("Salvar e voltar");
            dialog.addOption("Cancelar");dialog.init();result=dialog.execute();
        }
        if (result==1) {
            for (;;) {
                CDialog sizes("Tamanho da fonte: "+std::to_string(pending.fontSize));
                sizes.addOption("Aumentar (+1)");
                sizes.addOption("Diminuir (-1)");
                sizes.addOption("Concluir");
                sizes.init();const auto choice=sizes.execute();
                if(choice==1 && pending.fontSize<UserPreferences::maxFontSize)++pending.fontSize;
                else if(choice==2 && pending.fontSize>UserPreferences::minFontSize)--pending.fontSize;
                else if(choice!=1 && choice!=2)break;
            }
        } else if (result==2) pending.buttonLegend=!pending.buttonLegend;
        else if (result==3) pending.context=!pending.context;
        else if (result==4) pending.quickAccess=!pending.quickAccess;
        else if (result==5) pending.friendlyNames=!pending.friendlyNames;
        else if (result==6) {
            for (;;) {
                CDialog more("Layout e navegacao");
                more.addOption(std::string("Layout: ")+(pending.compactLayout?"Compacto":"Normal"));
                const char *panels[]={"Ativo","Esquerdo","Direito"};
                more.addOption(std::string("Abrir atalho no painel: ")+panels[pending.shortcutPanel]);
                more.addOption("Voltar");more.init();const auto option=more.execute();
                if(option==1)pending.compactLayout=!pending.compactLayout;
                else if(option==2)pending.shortcutPanel=(pending.shortcutPanel+1)%3;
                else break;
            }
        }
        else if (result==7) {
            std::string error;
            if(!pending.save("preferences.cfg",error)) {ErrorDialog("Erro ao salvar configuracoes",error);continue;}
            config().font_size=pending.fontSize;config().show_button_legend=pending.buttonLegend;config().show_context=pending.context;config().show_quick_access=pending.quickAccess;config().friendly_names=pending.friendlyNames;config().compact_layout=pending.compactLayout;config().shortcut_panel=pending.shortcutPanel;
            return true;
        } else return false;
    }
}
