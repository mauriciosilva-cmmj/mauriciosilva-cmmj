#ifndef _DEF_H_
#define _DEF_H_

#include <algorithm>
#include "config.h"

//~ #define INHIBIT(X) X
#define INHIBIT(X) /* X */

#ifndef FONTS
#define FONTS {"/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed.ttf",10},{"FreeSans.ttf",10},{"DroidSansFallback.ttf",9}
#endif

// Font stack to use on screens with low DPI.
#ifndef LOW_DPI_FONTS
#define LOW_DPI_FONTS {"Fiery_Turk.ttf",8},{"/usr/share/fonts/truetype/dejavu/DejaVuSansCondensed.ttf",10},{"FreeSans.ttf",10},{"DroidSansFallback.ttf",9}
#endif

// Panel
#define HEADER_H (std::max(17,config().font_size+8))
#define HEADER_H_PHYS static_cast<int>(HEADER_H * screen.ppu_y)
#define HEADER_PADDING_TOP 3
#define HEADER_PADDING_TOP_PHYS static_cast<int>(HEADER_PADDING_TOP * screen.ppu_y)

#define FOOTER_H (std::max(13,config().font_size+5))
#define FOOTER_H_PHYS static_cast<int>(FOOTER_H * screen.ppu_y)
#define FOOTER_PADDING_TOP 1
#define FOOTER_PADDING_TOP_PHYS static_cast<int>(FOOTER_PADDING_TOP * screen.ppu_y)

#define Y_LIST HEADER_H
#define Y_LIST_PHYS static_cast<int>(Y_LIST * screen.ppu_y)

#define LINE_HEIGHT (std::max(15,config().font_size+(config().compact_layout ? 3 : 6)))
#define LINE_HEIGHT_PHYS static_cast<int>(LINE_HEIGHT * screen.ppu_y)
 #define CONTEXT_H_PHYS (config().show_context ? 2 * LINE_HEIGHT_PHYS : 0)
#define QUICK_WIDTH_PHYS (config().show_quick_access && screen.actual_w >= static_cast<int>(360 * screen.ppu_x) ? screen.actual_w / 5 : 0)
#define FILE_PANEL_WIDTH_PHYS ((screen.actual_w - QUICK_WIDTH_PHYS) / 2)
#define PANEL_INFO_H_PHYS (2 * LINE_HEIGHT_PHYS + static_cast<int>(4 * screen.ppu_y))
#define PANEL_FOOTER_H_PHYS (FOOTER_H_PHYS + PANEL_INFO_H_PHYS + CONTEXT_H_PHYS)
#define NB_VISIBLE_LINES (std::max(1,(screen.actual_h - PANEL_FOOTER_H_PHYS - HEADER_H_PHYS - 1) / LINE_HEIGHT_PHYS + 1))
#define NB_FULLY_VISIBLE_LINES (std::max(1,(screen.actual_h - PANEL_FOOTER_H_PHYS - HEADER_H_PHYS) / LINE_HEIGHT_PHYS))

// Dialogs
#define DIALOG_BORDER 2
#define DIALOG_PADDING 8
// Colors
#define COLOR_TITLE_BG 102, 85, 74
#define COLOR_KEY 255, 0, 255
#define COLOR_TEXT_NORMAL 70, 27, 10
#define COLOR_TEXT_TITLE 233, 229, 227
#define COLOR_TEXT_DIR 75, 70, 164
#define COLOR_TEXT_SELECTED 255, 0, 0
#define COLOR_CURSOR_1 232, 152, 80
#define COLOR_CURSOR_2 232, 201, 173
#define COLOR_BG_1 255, 255, 255
#define COLOR_BG_2 232, 228, 224
#define COLOR_BORDER 102, 85, 74
#define COLOR_BORDER_ERROR 128, 55, 55

#endif // _DEF_H_
