#include "file_operations.h"
#include <cstdlib>
#include <iostream>
#include <stdexcept>

int main(int argc, char **argv) {
    if (argc < 4) return 64;
    using namespace FileOperations;
    Kind kind = std::string(argv[1]) == "copy" ? Kind::Copy :
        std::string(argv[1]) == "move" ? Kind::Move :
        std::string(argv[1]) == "delete" ? Kind::Remove : Kind::Extract;
    Callbacks cb;
    std::uint64_t last = 0, calls = 0, middle = 0;
    bool complete = false;
    const char *cancel = std::getenv("COMMANDER_CANCEL_AFTER");
    cb.progress = [&](const Progress &p) {
        if (p.done < last || p.done > p.total || p.items > p.itemTotal)
            throw std::runtime_error("Invalid progress counters");
        ++calls; if (p.done && p.done < p.total) ++middle;
        last = p.done; complete = p.complete;
        return !cancel || p.done < std::strtoull(cancel, nullptr, 10);
    };
    cb.overwrite = [](const std::string &) {
        const char *value = std::getenv("COMMANDER_OVERWRITE");
        const std::string action = value ? value : "all";
        return action == "skip" ? Decision::Skip : action == "cancel" ? Decision::Cancel : Decision::All;
    };
    std::vector<std::string> sources(argv + 3, argv + argc);
    auto result = run(kind, sources, argv[2], cb);
    std::cout << "cancelled=" << result.cancelled << " skipped=" << result.skipped
        << " complete=" << complete << " calls=" << calls << " middle=" << middle
        << " error=" << result.error << '\n';
    return !result.error.empty() ? 2 : result.cancelled ? 3 : 0;
}
