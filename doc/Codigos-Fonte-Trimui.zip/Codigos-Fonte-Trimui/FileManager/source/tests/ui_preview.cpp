#define SDL_MAIN_HANDLED
#include "../operation_progress.cpp"
#include <cstdlib>
#include <iostream>
#include <stdexcept>
Screen screen;
std::vector<CWindow *> Globals::g_windows;
const SDL_Color Globals::g_colorTextNormal{COLOR_TEXT_NORMAL};
const SDL_Color Globals::g_colorTextTitle{COLOR_TEXT_TITLE};
const SDL_Color Globals::g_colorTextDir{COLOR_TEXT_DIR};
const SDL_Color Globals::g_colorTextSelected{COLOR_TEXT_SELECTED};
Config &config() { static Config c; return c; }
CWindow::CWindow() { Globals::g_windows.push_back(this); }
CWindow::~CWindow() { Globals::g_windows.pop_back(); }
int CWindow::execute() { return 1; }
bool CWindow::isFullScreen() const { return false; }
bool CWindow::handlesTextInput() const { return false; }
void CWindow::onResize() {}
bool CWindow::onIdle() {return false;}
bool CWindow::keyPress(const SDL_Event &,SDLC_Keycode,ControllerButton) { return false; }
bool CWindow::keyHold() { return false; }
bool CWindow::gamepadHold(SDL_GameController *) { return false; }
bool CWindow::mouseDown(int,int,int) { return false; }
bool CWindow::mouseWheel(int,int) { return false; }
bool CWindow::textInput(const SDL_Event &) { return false; }
bool CWindow::tick(SDLC_Keycode) { return false; }
bool CWindow::tick(SDL_GameController *, ControllerButton) { return false; }
CResourceManager::CResourceManager() : m_low_dpi_fonts(false), m_fonts({TTF_OpenFont("res/FreeSans.ttf",20)}) {}
CResourceManager &CResourceManager::instance() { static CResourceManager r; return r; }
const Fonts &CResourceManager::getFonts() const { return m_fonts; }
int Screen::onResize(int w,int h) { surface=SDL_GetWindowSurface(window); actual_w=w; actual_h=h; return 0; }
namespace SDL_utils {
SDL_Surface *createSurface(int w,int h) { return SDL_CreateRGBSurface(0,w,h,32,0,0,0,0); }
SDL_Surface *createImage(int w,int h,Uint32 c) { auto s=createSurface(w,h);SDL_FillRect(s,nullptr,c);return s; }
SDL_Surface *renderText(const Fonts &f,const std::string &s,const SDL_Color &fg,const SDL_Color &bg) { return TTFMultiFont_RenderUTF8_Shaded(f,s,fg,bg); }
void applyPpuScaledSurface(Sint16 x,Sint16 y,SDL_Surface *s,SDL_Surface *d,SDL_Rect *c) { SDL_Rect r{x,y,0,0}; if(s)SDL_BlitSurface(s,c,d,&r); }
void renderRectWithBorder(SDL_Surface *s,SDL_Rect r,int bx,int by,Uint32 c,Uint32 bg) {SDL_FillRect(s,&r,c);r.x+=bx;r.y+=by;r.w-=2*bx;r.h-=2*by;SDL_FillRect(s,&r,bg);}
void renderAll() {SDL_FillRect(screen.surface,nullptr,SDL_MapRGB(screen.surface->format,232,228,224));for(auto w:Globals::g_windows)w->render(true);}
}
int main() {
    _putenv_s("PWD",".");_putenv_s("HOME",".");
    SDL_SetMainReady();if(SDL_Init(SDL_INIT_VIDEO))return 1;if(TTF_Init())return 2;
    screen.ppu_x=screen.ppu_y=2;screen.actual_w=1280;screen.actual_h=720;
    screen.window=SDL_CreateWindow("Progress verification",0,0,1280,720,SDL_WINDOW_HIDDEN);
    screen.surface=SDL_GetWindowSurface(screen.window); if(!screen.surface)return 3;
    {
        ProgressWindow view;
        for(const auto &phase:{"Preparing","Copying","Moving","Deleting","Extracting"}) {
            FileOperations::Progress p;p.phase=phase;p.path="/mnt/SDCARD/ROMs/PlayStation/arquivo grande.zip";
            p.done=51*1024*1024+12;p.total=100*1024*1024+24;p.items=12;p.itemTotal=24;
            if(!view.update(p))return 4;
            const auto image=std::string("build/progress-")+phase+".bmp";
            if(SDL_SaveBMP(screen.surface,image.c_str()))return 5;
        }
        SDL_Event cancel{};cancel.type=SDL_CONTROLLERBUTTONDOWN;cancel.cbutton.button=SDL_CONTROLLER_BUTTON_A;
        SDL_PushEvent(&cancel);FileOperations::Progress p;
        if(view.update(p))return 6;
        cancel.type=SDL_KEYDOWN;cancel.key.keysym.sym=config().key_parent;SDL_PushEvent(&cancel);
        if(view.update(p) && view.update(p))return 7;
    }
    std::cout<<"Rendered all four operations and preparation; keyboard/controller cancellation passed\n";
    TTF_Quit();SDL_Quit();return 0;
}
