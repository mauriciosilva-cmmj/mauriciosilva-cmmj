#include "selection_context.h"
#include <cassert>
#include <string>
int main() {
 auto md=describeSelection("/mnt/SDCARD/Roms","MD",true);
 assert(md.title=="Sega Mega Drive");
 auto normal=describeSelection("/mnt/SDCARD/Documents","MD",true);
 assert(normal.title=="MD" && normal.detail=="Pasta");
 auto unknown=describeSelection("/mnt/SDCARD/Roms","XYZ",true);
 assert(unknown.title=="XYZ" && unknown.detail=="Pasta");
 auto invalid=describeSelection("/nonexistent","missing.zip",false);
 assert(invalid.detail=="Arquivo indisponivel");
}
