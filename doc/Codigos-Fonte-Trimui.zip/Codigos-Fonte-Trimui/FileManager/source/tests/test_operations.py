import os, pathlib, subprocess, tempfile, unittest, zipfile, struct, re
ROOT=pathlib.Path(__file__).resolve().parents[2]
DRIVER=ROOT/'build/operations-test.exe'
class Operations(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='commander-test-',dir=ROOT/'build')
        self.base=pathlib.Path(self.tmp.name).resolve()
        assert self.base.is_relative_to((ROOT/'build').resolve())
        self.src=self.base/'src'; self.dst=self.base/'dst'
        self.src.mkdir(); self.dst.mkdir()
    def tearDown(self):
        assert self.base.is_relative_to((ROOT/'build').resolve())
        self.tmp.cleanup()
    def runop(self,kind,*paths,expected=0,**env):
        runenv=os.environ.copy(); runenv.update({'COMMANDER_'+k.upper():str(v) for k,v in env.items()})
        r=subprocess.run([str(DRIVER),kind,str(self.dst),*map(str,paths)],capture_output=True,text=True,encoding='utf-8',env=runenv)
        self.assertEqual(r.returncode,expected,r.stdout+r.stderr)
        if expected==0:self.assertIn('complete=1',r.stdout)
        self.assertFalse(list(self.dst.rglob('.commander-*.tmp')))
        return r.stdout
    def file(self,name='large.bin',data=None):
        p=self.src/name; p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(data if data is not None else bytes(range(256))*24576)
        return p
    def archive(self,entries,name='data.zip',compression=zipfile.ZIP_DEFLATED):
        p=self.src/name
        with zipfile.ZipFile(p,'w',compression=compression) as z:
            for key,data in entries:z.writestr(key,data)
        return p
    def test_copy_large_progress(self):
        p=self.file(); out=self.runop('copy',p)
        self.assertEqual(p.read_bytes(),(self.dst/p.name).read_bytes())
        self.assertRegex(out,r'middle=[1-9]')
    def test_copy_tree_and_empty(self):
        self.file('tree/sub/file.bin'); self.file('tree/empty',b''); (self.src/'tree/emptydir').mkdir()
        self.runop('copy',self.src/'tree'); self.assertTrue((self.dst/'tree/emptydir').is_dir())
        self.assertEqual((self.dst/'tree/empty').stat().st_size,0)
    def test_copy_overwrite(self):
        p=self.file(data=b'new'); (self.dst/p.name).write_bytes(b'old'); self.runop('copy',p)
        self.assertEqual((self.dst/p.name).read_bytes(),b'new')
    def test_copy_skip(self):
        p=self.file(data=b'new'); (self.dst/p.name).write_bytes(b'old')
        self.assertIn('skipped=1',self.runop('copy',p,overwrite='skip'))
        self.assertEqual((self.dst/p.name).read_bytes(),b'old')
    def test_copy_cancel_keeps_original(self):
        p=self.file(); (self.dst/p.name).write_bytes(b'old')
        self.runop('copy',p,expected=3,cancel_after=262144)
        self.assertEqual((self.dst/p.name).read_bytes(),b'old'); self.assertTrue(p.exists())
    def test_same_path_rejected(self):
        p=self.file(data=b'safe'); self.dst=self.src
        self.runop('copy',p,expected=2); self.assertEqual(p.read_bytes(),b'safe')
    def test_descendant_rejected(self):
        self.file('tree/a',b'safe'); self.dst=self.src/'tree'; self.runop('copy',self.src/'tree',expected=2)
    def test_overlap_rejected(self):
        p=self.file('tree/a',b'safe'); self.runop('delete',self.src/'tree',p,expected=2); self.assertTrue(p.exists())
    def test_hardlink_rejected(self):
        p=self.file(data=b'safe'); os.link(p,self.dst/p.name); self.runop('copy',p,expected=2); self.assertEqual(p.read_bytes(),b'safe')
    def test_move_tree(self):
        self.file('tree/sub/a',b'move'); self.file('tree/empty',b'')
        self.runop('move',self.src/'tree'); self.assertFalse((self.src/'tree').exists()); self.assertEqual((self.dst/'tree/sub/a').read_bytes(),b'move')
    def test_move_skip_keeps_source(self):
        p=self.file('tree/a',b'new'); (self.dst/'tree').mkdir(); (self.dst/'tree/a').write_bytes(b'old')
        self.runop('move',self.src/'tree',overwrite='skip'); self.assertEqual(p.read_bytes(),b'new'); self.assertEqual((self.dst/'tree/a').read_bytes(),b'old')
    def test_delete_tree(self):
        self.file('tree/sub/a',b'del'); self.file('tree/empty',b'')
        self.assertRegex(self.runop('delete',self.src/'tree'),r'middle=[1-9]'); self.assertFalse((self.src/'tree').exists())
    def test_delete_cancel(self):
        p=self.file('a',b'a'); q=self.file('b',b'b')
        self.runop('delete',p,q,expected=3,cancel_after=1); self.assertTrue(p.exists()); self.assertFalse(q.exists())
    def test_extract_tree_and_unicode(self):
        p=self.archive([('pasta/',b''),('pasta/arquivo.txt',b'abc'),('vazio/',b''),('empty',b''),('a\u00e7\u00e3o.txt',b'utf8'),('big.bin',b'x'*(5*1024*1024))])
        out=self.runop('extract',p); self.assertEqual((self.dst/'pasta/arquivo.txt').read_bytes(),b'abc'); self.assertTrue((self.dst/'vazio').is_dir()); self.assertTrue((self.dst/'a\u00e7\u00e3o.txt').exists()); self.assertRegex(out,r'middle=[1-9]')
    def test_extract_stored_multiple(self):
        a=self.archive([('a',b'a')],compression=zipfile.ZIP_STORED); b=self.archive([('b',b'b')],name='b.ZIP')
        self.runop('extract',a,b); self.assertEqual((self.dst/'a').read_bytes(),b'a'); self.assertEqual((self.dst/'b').read_bytes(),b'b')
    def test_extract_zip64(self):
        p=self.src/'64.zip'
        with zipfile.ZipFile(p,'w') as z:
            with z.open('file','w',force_zip64=True) as f:f.write(b'zip64')
        self.runop('extract',p); self.assertEqual((self.dst/'file').read_bytes(),b'zip64')
    def test_extract_cancel_keeps_original(self):
        p=self.archive([('big',b'x'*(5*1024*1024))]); (self.dst/'big').write_bytes(b'old')
        self.runop('extract',p,expected=3,cancel_after=65536); self.assertEqual((self.dst/'big').read_bytes(),b'old')
    def test_extract_skip(self):
        p=self.archive([('a',b'new')]); (self.dst/'a').write_bytes(b'old')
        self.assertIn('skipped=1',self.runop('extract',p,overwrite='skip')); self.assertEqual((self.dst/'a').read_bytes(),b'old')
    def test_extract_paths_rejected_before_writes(self):
        for path in ['../escape','/absolute','C:/escape','a/../../escape','..\\escape','\\\\server\\share']:
            with self.subTest(path=path):
                p=self.archive([('innocent',b'no'),(path,b'bad')]); self.runop('extract',p,expected=2); self.assertFalse((self.dst/'innocent').exists())
    def test_extract_link_rejected(self):
        p=self.src/'link.zip'; info=zipfile.ZipInfo('link'); info.create_system=3; info.external_attr=0o120777<<16
        with zipfile.ZipFile(p,'w') as z:z.writestr(info,'../outside')
        self.runop('extract',p,expected=2); self.assertFalse((self.dst/'link').exists())
    def test_extract_corrupt_preserves_old(self):
        p=self.archive([('a',b'hello')],compression=zipfile.ZIP_STORED); data=bytearray(p.read_bytes()); pos=data.index(b'hello'); data[pos]=ord('X'); p.write_bytes(data)
        (self.dst/'a').write_bytes(b'old'); self.runop('extract',p,expected=2); self.assertEqual((self.dst/'a').read_bytes(),b'old')
    def test_extract_encrypted_rejected(self):
        p=self.archive([('a',b'hello')]); data=bytearray(p.read_bytes())
        for marker,offset in [(b'PK\x03\x04',6),(b'PK\x01\x02',8)]:
            pos=data.index(marker); flags=struct.unpack_from('<H',data,pos+offset)[0]; struct.pack_into('<H',data,pos+offset,flags|1)
        p.write_bytes(data); self.runop('extract',p,expected=2); self.assertFalse((self.dst/'a').exists())
    def test_extract_cannot_overwrite_archive(self):
        p=self.archive([('data.zip',b'bad')]); original=p.read_bytes(); self.dst=self.src
        self.runop('extract',p,expected=2); self.assertEqual(p.read_bytes(),original)
    def test_extract_empty_archive(self):
        p=self.archive([]); self.runop('extract',p); self.assertEqual(list(self.dst.iterdir()),[])
    def test_extract_invalid_archive(self):
        p=self.file('bad.zip',b'not a zip'); self.runop('extract',p,expected=2)
    def test_file_blocks_destination_directory(self):
        p=self.archive([('a/b',b'new')]); (self.dst/'a').write_bytes(b'old'); self.runop('extract',p,expected=2); self.assertEqual((self.dst/'a').read_bytes(),b'old')
    def test_links_never_followed(self):
        p=self.file('safe',b'outside'); target=self.dst/'link'
        try:os.symlink(self.src,target,target_is_directory=True)
        except OSError:self.skipTest('Windows requires permission to create symlinks')
        z=self.archive([('link/safe',b'bad')]); self.runop('extract',z,expected=2); self.assertEqual(p.read_bytes(),b'outside')
        self.runop('delete',target); self.assertTrue(p.exists())
if __name__=='__main__':unittest.main(verbosity=2)
