#include "user_preferences.h"
#include "storage_info.h"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>

int main(int argc,char **argv) {
    assert(argc==2);
    namespace fs=std::filesystem;
    const fs::path root=argv[1];fs::create_directories(root);
    const auto file=(root/"preferences.cfg").string();
    auto p=UserPreferences::load((root/"missing").string());assert(p.fontSize==10 && p.buttonLegend);
    std::string error;
    p.fontSize=16;p.buttonLegend=false;assert(p.save(file,error));
    auto q=UserPreferences::load(file);assert(q.fontSize==16 && !q.buttonLegend);
    p.fontSize=8;p.buttonLegend=true;assert(p.save(file,error));
    q=UserPreferences::load(file);assert(q.fontSize==8 && q.buttonLegend);
    {std::ofstream o(file);o<<"font_size=999999\nshow_button_legend=0\n";}
    q=UserPreferences::load(file);assert(q.fontSize==24 && !q.buttonLegend);
    {std::ofstream o(file);o<<"font_size=-20\nshow_button_legend=1\n";}
    q=UserPreferences::load(file);assert(q.fontSize==8 && q.buttonLegend);
    {std::ofstream o(file);o<<"font_size=bad\nshow_button_legend=bad\nfont_size=12 junk\nshow_button_legend=9\n";}
    q=UserPreferences::load(file);assert(q.fontSize==10 && q.buttonLegend);
    assert(!p.save((root/"missing/path").string(),error));assert(!error.empty());
    assert(!p.save(root.string(),error));
    for(const auto &entry:fs::directory_iterator(root))assert(entry.path().filename().string().find(".tmp-")==std::string::npos);
    using namespace StorageInfo;
    std::istringstream mounts(
        "/dev/root / squashfs ro,relatime 0 0\n"
        "proc /proc proc rw 0 0\n"
        "tmpfs /tmp tmpfs rw 0 0\n"
        "/dev/mmcblk1p1 /mnt/SDCARD vfat rw 0 0\n"
        "/dev/mmcblk1p1 /mnt/SDCARD/alias vfat rw 0 0\n"
        "/dev/sda1 /mnt/USB\\040DRIVE exfat rw 0 0\n"
        "/dev/loop0 /mnt/rom ext4 ro 0 0\n");
    auto v=parseMounts(mounts);assert(v.size()==3);
    assert(v[0].kind==Kind::SdCard && v[0].name=="SDCARD");
    assert(v[1].kind==Kind::Usb && v[1].name=="USB DRIVE");
    assert(v[2].kind==Kind::Internal && v[2].readOnly);
    assert(!v[0].capacityKnown);
    std::istringstream internal("/dev/root / squashfs ro 0 0\n/dev/mmcblk0p4 /mnt/UDISK ext4 rw 0 0\n/dev/sda1 /media/ONE vfat rw 0 0\n/dev/sdb1 /media/TWO vfat ro 0 0\n");
    v=parseMounts(internal);assert(v.size()==3 && v[2].mount=="/mnt/UDISK" && !v[2].readOnly);
    std::istringstream overlay("overlay / overlay rw 0 0\n");v=parseMounts(overlay);assert(v.size()==1 && v[0].kind==Kind::Internal);
    std::istringstream unplugged("proc /proc proc rw 0 0\n");assert(parseMounts(unplugged).empty());
    assert(formatBytes(1024)=="1.0 KiB");assert(formatBytes(0)=="0.0 B");
    Volume card{Kind::SdCard,"/dev/mmcblk1p1","/mnt/SDCARD","GAMES",1024,2048,true,false};
    assert(description(card).find("SDCARD [GAMES]")!=std::string::npos);
    assert(description(card).find("1.0 KiB / 2.0 KiB")!=std::string::npos);
    std::cout<<"Preferences: persistence/replacement/clamping/invalid input/write errors passed.\n"
             <<"Storage: SD/USB/internal, root fallback, names, escapes, bind duplicates, multiple USB, removal and capacities passed.\n";
}
