#include "quick_access.h"
#include "config.h"
#include "def.h"
#include "dialog.h"
#include "error_dialog.h"
#include "keyboard.h"
#include "resourceManager.h"
#include "screen.h"
#include "sdlutils.h"
#include "storage_info.h"
#include <algorithm>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <sys/stat.h>
#include <unistd.h>

namespace {
bool directory(const std::string &p) { struct stat st{};return !p.empty() && ::stat(p.c_str(),&st)==0 && S_ISDIR(st.st_mode); }
std::string edit(const std::string &value) { CKeyboard k(value);return k.execute()==1 ? k.getInputText() : value; }
std::string base(const std::string &p) {const auto pos=p.find_last_of('/');return pos==std::string::npos?p:p.substr(pos+1);}
void writeText(int x,int y,int width,const std::string &value,SDL_Color bg) {
    SDLSurfaceUniquePtr surface{SDL_utils::renderText(CResourceManager::instance().getFonts(),value,{COLOR_TEXT_NORMAL},bg)};
    if(!surface)return;auto clip=SDL_utils::makeRect(0,0,std::max(0,std::min(width,surface->w)),surface->h);
    SDL_utils::applyPpuScaledSurface(x,y,surface.get(),screen.surface,&clip);
}
}
bool QuickAccess::save(const std::vector<Shortcut> &items) {
    const std::string tmp="shortcuts.cfg.tmp-"+std::to_string(::getpid());
    FILE *file=std::fopen(tmp.c_str(),"wbx");
    if(!file){ErrorDialog("Atalhos","Nao foi possivel criar arquivo temporario");return false;}
    bool ok=true;
    for(const auto &v:items) {
        // USB is discovered from currently mounted devices at runtime.
        if(v.icon=="USB" && !v.custom)continue;
        std::ostringstream row;row<<std::quoted(v.label)<<' '<<std::quoted(v.path)<<' '<<std::quoted(v.icon)<<' '<<v.custom<<'\n';
        auto s=row.str();ok=std::fwrite(s.data(),1,s.size(),file)==s.size() && ok;
    }
    ok=std::fflush(file)==0 && ok;ok=::fsync(::fileno(file))==0 && ok;ok=std::fclose(file)==0 && ok;
    if(ok)ok=std::rename(tmp.c_str(),"shortcuts.cfg")==0;
    if(!ok){std::remove(tmp.c_str());ErrorDialog("Atalhos","Nao foi possivel salvar os atalhos");return false;}
    entries_=items;return true;
}
void QuickAccess::load() {
    entries_.clear();
    std::ifstream in("shortcuts.cfg");
    if(in) {
        std::string line;
        while(entries_.size()<128 && std::getline(in,line)) {
            std::istringstream row(line);Shortcut item;
            if(row>>std::quoted(item.label)>>std::quoted(item.path)>>std::quoted(item.icon)>>item.custom)
                if(!item.label.empty() && item.label.size()<=128 && item.path.size()<=2048)entries_.push_back(item);
        }
    } else {
        // Look for known folders under the detected SD mount; absent items remain editable.
        std::string root;
        for(const auto &v:StorageInfo::connected())if(v.kind==StorageInfo::Kind::SdCard){root=v.mount;break;}
        const auto detect=[&](std::initializer_list<const char*> names) {
            for(auto n:names){const auto p=root+"/"+n;if(!root.empty() && directory(p))return p;}return std::string();
        };
        entries_={{"ROMs",detect({"Roms","ROMS"}),"R"},{"Emuladores",detect({"Emus"}),"E"},
            {"BIOS",detect({"BIOS","Bios"}),"B"},{"Videos",detect({"Videos","Video","Movies"}),"V"},
            {"Musica",detect({"Music","Musica"}),"M"},{"Fotos",detect({"Photos","Pictures","Imgs"}),"F"},
            {"Downloads",detect({"Downloads","Download"}),"D"}};
    }
    refreshUsb();selected_=std::min<unsigned>(selected_,entries_.empty()?0:entries_.size()-1);
}
void QuickAccess::refreshUsb() {
    const bool hadSelection=selected_<entries_.size();
    const Shortcut previous=hadSelection?entries_[selected_]:Shortcut{};
    entries_.erase(std::remove_if(entries_.begin(),entries_.end(),[](const Shortcut &s){return s.icon=="USB" && !s.custom;}),entries_.end());
    bool found=false;
    for(const auto &v:StorageInfo::connected())if(v.kind==StorageInfo::Kind::Usb){entries_.push_back({"USB: "+v.name,v.mount,"USB",false});found=true;}
    if(!found)entries_.push_back({"USB indisponivel","","USB",false});
    if(hadSelection) {
        const auto it=std::find_if(entries_.begin(),entries_.end(),[&](const Shortcut &s){
            return s.label==previous.label && s.path==previous.path && s.icon==previous.icon && s.custom==previous.custom;
        });
        if(it!=entries_.end())selected_=static_cast<unsigned>(it-entries_.begin());
        else if(previous.icon=="USB" && !previous.custom)selected_=static_cast<unsigned>(entries_.size()-1);
    }
    if(selected_>=entries_.size())selected_=entries_.empty()?0:entries_.size()-1;
}
const Shortcut *QuickAccess::selected() const {return selected_<entries_.size()?&entries_[selected_]:nullptr;}
bool QuickAccess::move(int delta) {
    if(entries_.empty())return false;const int next=std::max(0,std::min(static_cast<int>(entries_.size())-1,static_cast<int>(selected_)+delta));
    if(next==static_cast<int>(selected_))return false;selected_=next;return true;
}
void QuickAccess::render(bool focused) {
    const int width=QUICK_WIDTH_PHYS, y=Y_LIST_PHYS, height=screen.actual_h-PANEL_FOOTER_H_PHYS-y;
    if(width<=0)return;
    auto rect=SDL_utils::makeRect(0,0,width,screen.actual_h-PANEL_FOOTER_H_PHYS);
    SDL_FillRect(screen.surface,&rect,SDL_MapRGB(screen.surface->format,COLOR_BG_2));
    auto head=SDL_utils::makeRect(0,0,width,HEADER_H_PHYS);SDL_FillRect(screen.surface,&head,SDL_MapRGB(screen.surface->format,COLOR_TITLE_BG));
    SDLSurfaceUniquePtr title{SDL_utils::renderText(CResourceManager::instance().getFonts(),"Acesso rapido",{COLOR_TEXT_TITLE},{COLOR_TITLE_BG})};
    if(title){auto clip=SDL_utils::makeRect(0,0,std::min(width,title->w),title->h);SDL_utils::applyPpuScaledSurface(2,2,title.get(),screen.surface,&clip);}
    const int rows=std::max(1,height/LINE_HEIGHT_PHYS);
    if(selected_<first_)first_=selected_;if(selected_>=first_+rows)first_=selected_-rows+1;
    for(int row=0;row<rows && first_+row<entries_.size();++row) {
        const unsigned index=first_+row;const auto &entry=entries_[index];
        SDL_Color bg=index==selected_ && focused?SDL_Color{COLOR_CURSOR_1}:SDL_Color{COLOR_BG_2};
        auto line=SDL_utils::makeRect(0,y+row*LINE_HEIGHT_PHYS,width,LINE_HEIGHT_PHYS);SDL_FillRect(screen.surface,&line,SDL_utils::mapRGB(screen.surface->format,bg));
        writeText(3,y+row*LINE_HEIGHT_PHYS,width-6,"["+entry.icon+"] "+entry.label,bg);
    }
}
void QuickAccess::addFavorite(const std::string &path) {
    if(!directory(path)){ErrorDialog("Favoritos","Pasta indisponivel");return;}
    auto label=edit(base(path).empty()?path:base(path));if(label.empty())return;
    auto copy=entries_;copy.push_back({label,path,"*",true});if(save(copy))selected_=copy.size()-1;
}
void QuickAccess::manage(const std::string &currentPath) {
    auto *item=selected();if(!item)return;
    const auto current=*item;
    CDialog d(current.label);d.addOption("Editar caminho");d.addOption("Renomear");d.addOption("Mover para cima");d.addOption("Mover para baixo");
    if(current.custom)d.addOption("Remover favorito");
    d.addOption("Adicionar pasta atual");d.addOption("Voltar");d.init();const int choice=d.execute();
    auto copy=entries_;
    if(choice==1 && current.icon!="USB")copy[selected_].path=edit(current.path);
    else if(choice==2 && current.icon!="USB"){const auto name=edit(current.label);if(!name.empty())copy[selected_].label=name;}
    else if(choice==3 && selected_>0){std::swap(copy[selected_],copy[selected_-1]);if(save(copy))--selected_;return;}
    else if(choice==4 && selected_+1<copy.size()){std::swap(copy[selected_],copy[selected_+1]);if(save(copy))++selected_;return;}
    else if(choice==5 && current.custom){CDialog c("Remover favorito?");c.addLabel(current.label);c.addOption("Sim");c.addOption("Nao");c.init();if(c.execute()!=1)return;copy.erase(copy.begin()+selected_);if(save(copy) && selected_>=entries_.size() && selected_)--selected_;return;}
    else if(choice==(current.custom?6:5)){addFavorite(currentPath);return;}
    else return;
    save(copy);
}
