#pragma once
#include <string>
#include <vector>
struct Shortcut { std::string label, path, icon; bool custom = false; };
class QuickAccess {
    std::vector<Shortcut> entries_;
    unsigned selected_ = 0, first_ = 0;
    bool save(const std::vector<Shortcut> &entries);
public:
    void load();
    void refreshUsb();
    void render(bool focused);
    bool move(int delta);
    const Shortcut *selected() const;
    void manage(const std::string &currentPath);
    void addFavorite(const std::string &currentPath);
};
