#pragma once
#include "file_operations.h"

void RunFileOperation(FileOperations::Kind kind,
    const std::vector<std::string> &sources, const std::string &destination);
