#include "selection_context.h"
#include "storage_info.h"
#include "config.h"
#include <algorithm>
#include <cctype>
#include <ctime>
#include <fstream>
#include <sstream>
#include <sys/stat.h>

namespace {
std::string upper(std::string v) {
    for (char &c:v) c=static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
    return v;
}
std::string basename(const std::string &p) {
    auto end=p.find_last_not_of('/');
    if (end==std::string::npos) return "/";
    auto start=p.rfind('/',end);return p.substr(start==std::string::npos?0:start+1,end-(start==std::string::npos?0:start+1)+1);
}
}
SelectionContext describeSelection(const std::string &parent, const std::string &name, bool directory) {
    SelectionContext result;
    result.path=parent+(parent=="/"?"":"/")+name;
    result.title=name;result.directory=directory;
    if (directory) {
        result.detail="Pasta";
        const auto base=upper(basename(parent));
        if (config().friendly_names && name!=".." && (base=="ROMS" || base=="EMUS")) {
            // Tab-separated, editable table: folder alias, friendly name, description.
            std::ifstream table("res/consoles.tsv");std::string line;
            const auto alias=upper(name);
            while (std::getline(table,line)) {
                if(line.empty()||line[0]=='#')continue;
                std::istringstream fields(line);std::string id,title,description;
                if(!std::getline(fields,id,'\t')||!std::getline(fields,title,'\t')||!std::getline(fields,description))continue;
                if(!description.empty()&&description.back()=='\r')description.pop_back();
                if(upper(id)==alias) {result.title=title;result.detail=description;break;}
            }
        }
    } else {
        struct stat info{};
        if (::stat(result.path.c_str(),&info)!=0) {result.detail="Arquivo indisponivel";return result;}
        auto dot=name.rfind('.');
        std::string ext=dot==std::string::npos?"arquivo":upper(name.substr(dot+1));
        std::tm *tm=std::localtime(&info.st_mtime);char time[24]{};
        if(tm)std::strftime(time,sizeof(time),"%d/%m/%Y %H:%M",tm);
        result.detail=ext+" | "+StorageInfo::formatBytes(info.st_size)+" | "+time;
        if(ext=="ZIP")result.detail+=" | X: extrair para painel direito";
    }
    return result;
}
