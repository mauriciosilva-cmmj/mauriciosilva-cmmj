#include "browser_chrome.h"
#include "config.h"
#include "selection_context.h"
#include "def.h"
#include "dialog.h"
#include "resourceManager.h"
#include "screen.h"
#include "sdlutils.h"
#include <algorithm>

namespace {
void text(SDL_Surface *out, int x, int y, int width, const std::string &s,
    SDL_Color foreground = {COLOR_TEXT_TITLE}, SDL_Color background = {COLOR_TITLE_BG}) {
    SDLSurfaceUniquePtr image{SDL_utils::renderText(CResourceManager::instance().getFonts(),s,foreground,background)};
    if (!image || width <= 0) return;
    auto clip = SDL_utils::makeRect(0,0,std::min(width,image->w),image->h);
    SDL_utils::applyPpuScaledSurface(x,y,image.get(),out,&clip);
}
SDLSurfaceUniquePtr drawLegend(int width, int height) {
    SDLSurfaceUniquePtr out{SDL_utils::createImage(width,height,SDL_MapRGB(screen.surface->format,COLOR_BG_2))};
    const auto border=SDL_MapRGB(out->format,COLOR_BORDER);
    auto box=SDL_utils::makeRect(0,0,width,height);
    SDL_utils::renderRectWithBorder(out.get(),box,2,border,SDL_MapRGB(out->format,COLOR_BG_2));
    const auto &fonts=CResourceManager::instance().getFonts();
    const int unit=LINE_HEIGHT_PHYS, radius=std::max(7,unit/2-2), cx=width/2, cy=height/2;
    const char *keys[]={"X","Y","A","B"};
    const char *labels[]={"Operacoes","Sistema","Abrir","Voltar"};
    const SDL_Color colors[]={{40,100,190,255},{170,130,10,255},{50,135,70,255},{190,55,50,255}};
    const int xs[]={cx,cx-unit*2,cx+unit*2,cx};
    const int ys[]={cy-unit,cy,cy,cy+unit};
    for(int i=0;i<4;++i) {
        const auto color=SDL_utils::mapRGB(out->format,colors[i]);
        for(int y=-radius;y<=radius;++y) {
            int dx=0;while((dx+1)*(dx+1)+y*y<=radius*radius)++dx;
            auto row=SDL_utils::makeRect(xs[i]-dx,ys[i]+y,2*dx+1,1);SDL_FillRect(out.get(),&row,color);
        }
        SDLSurfaceUniquePtr glyph{SDL_utils::renderText(fonts,keys[i],{255,255,255,255},colors[i])};
        if(glyph)SDL_utils::applyPpuScaledSurface(xs[i]-glyph->w/2,ys[i]-glyph->h/2,glyph.get(),out.get());
        if(i==1) {const auto w=SDL_utils::measureText(fonts,labels[i]).first; text(out.get(),std::max(4,xs[i]-radius-4-w),ys[i]-unit/2,std::max(1,xs[i]-radius-8),labels[i],{COLOR_TEXT_NORMAL},{COLOR_BG_2});}
        else text(out.get(),xs[i]+radius+5,ys[i]-unit/2,std::max(1,width-xs[i]-radius-9),labels[i],{COLOR_TEXT_NORMAL},{COLOR_BG_2});
    }
    return out;
}
}

bool BrowserChrome::refresh(bool force) {
    const auto now = SDL_GetTicks();
    if (!force && initialized_ && now-lastRefresh_<3000) return false;
    volumes_=StorageInfo::connected();lastRefresh_=now;initialized_=true;
    return true;
}

void BrowserChrome::render() const {
    const int y=screen.actual_h-PANEL_INFO_H_PHYS;
    const int pad=std::max(4,static_cast<int>(5*screen.ppu_x));
    auto area=SDL_utils::makeRect(0,y,screen.actual_w,PANEL_INFO_H_PHYS);
    SDL_FillRect(screen.surface,&area,SDL_MapRGB(screen.surface->format,COLOR_TITLE_BG));
    const std::size_t pages=std::max<std::size_t>(1,(volumes_.size()+1)/2);
    const auto page=(SDL_GetTicks()/6000)%pages;
    const int columns=static_cast<int>(std::min<std::size_t>(2,std::max<std::size_t>(1,volumes_.size()-std::min(volumes_.size(),page*2))));
    const int cell=screen.actual_w/columns;
    if(volumes_.empty()) text(screen.surface,pad,y+2,screen.actual_w-2*pad,"Nenhum volume identificado");
    for(int i=0;i<columns && page*2+i<volumes_.size();++i) {
        const auto &v=volumes_[page*2+i];
        const int x=i*cell+pad, w=cell-2*pad;
        std::string label=StorageInfo::kindName(v.kind)+" ["+v.name+"]"+(v.readOnly?" [RO]":"");
        text(screen.surface,x,y+2,w,label);
        const int barY=y+LINE_HEIGHT_PHYS+2;
        const int barW=std::max(1,w/3), barH=std::max(8,LINE_HEIGHT_PHYS/2);
        auto bar=SDL_utils::makeRect(x,barY,barW,barH);
        SDL_utils::renderRectWithBorder(screen.surface,bar,1,SDL_MapRGB(screen.surface->format,232,228,224),SDL_MapRGB(screen.surface->format,55,46,41));
        if(v.capacityKnown && v.total) {
            const auto used=v.total-std::min(v.free,v.total);
            const int percent=static_cast<int>(100.0L*used/v.total);
            auto fill=SDL_utils::makeRect(x+1,barY+1,std::max(0,static_cast<int>((barW-2)*(static_cast<long double>(used)/v.total))),barH-2);
            SDL_FillRect(screen.surface,&fill,SDL_MapRGB(screen.surface->format,COLOR_CURSOR_1));
            const std::string info=std::to_string(percent)+"%  "+StorageInfo::formatBytes(v.free)+" livre / "+StorageInfo::formatBytes(v.total);
            text(screen.surface,x+barW+pad,y+LINE_HEIGHT_PHYS,w-barW-pad,info);
        } else text(screen.surface,x+barW+pad,y+LINE_HEIGHT_PHYS,w-barW-pad,"Indisponivel");
    }
    if(config().show_button_legend) {
        const int width=std::min(screen.actual_w/2,std::max(static_cast<int>(240*screen.ppu_x),LINE_HEIGHT_PHYS*11));
        const int height=3*LINE_HEIGHT_PHYS+static_cast<int>(12*screen.ppu_y);
        if(!legend_ || legend_->w!=width || legend_->h!=height)legend_=drawLegend(width,height);
        SDL_utils::applyPpuScaledSurface(screen.actual_w-width-pad,y-height-pad-CONTEXT_H_PHYS,legend_.get(),screen.surface);
    }
}

void BrowserChrome::renderContext(const std::string &parent, const std::string &name, bool directory) const {
    if(!config().show_context)return;
    const int y=screen.actual_h-PANEL_INFO_H_PHYS-CONTEXT_H_PHYS;
    const int pad=std::max(4,static_cast<int>(5*screen.ppu_x));
    auto area=SDL_utils::makeRect(0,y,screen.actual_w,CONTEXT_H_PHYS);
    SDL_FillRect(screen.surface,&area,SDL_MapRGB(screen.surface->format,COLOR_BG_2));
    const auto item=describeSelection(parent,name,directory);
    text(screen.surface,pad,y,screen.actual_w-2*pad,(directory?"[Pasta] ":"[Arquivo] ")+item.title+"  |  "+item.detail,{COLOR_TEXT_NORMAL},{COLOR_BG_2});
    text(screen.surface,pad,y+LINE_HEIGHT_PHYS,screen.actual_w-2*pad,item.path,{COLOR_TEXT_NORMAL},{COLOR_BG_2});
}

void BrowserChrome::renderShortcut(const std::string &label, const std::string &path) const {
    if(!config().show_context)return;
    const int y=screen.actual_h-PANEL_INFO_H_PHYS-CONTEXT_H_PHYS;
    const int pad=std::max(4,static_cast<int>(5*screen.ppu_x));
    auto area=SDL_utils::makeRect(0,y,screen.actual_w,CONTEXT_H_PHYS);
    SDL_FillRect(screen.surface,&area,SDL_MapRGB(screen.surface->format,COLOR_BG_2));
    text(screen.surface,pad,y,screen.actual_w-2*pad,"[Atalho] "+label,{COLOR_TEXT_NORMAL},{COLOR_BG_2});
    text(screen.surface,pad,y+LINE_HEIGHT_PHYS,screen.actual_w-2*pad,path.empty()?"Indisponivel: configure o caminho com X":path,{COLOR_TEXT_NORMAL},{COLOR_BG_2});
}

void BrowserChrome::showDisks() const {
    if (volumes_.empty()) {
        CDialog dialog("Discos conectados");dialog.addLabel("Nenhum volume identificado");dialog.addOption("Voltar");dialog.init();dialog.execute();return;
    }
    for (std::size_t i=0;i<volumes_.size();++i) {
        const auto &v=volumes_[i];
        CDialog dialog("Disco "+std::to_string(i+1)+" / "+std::to_string(volumes_.size()));
        dialog.addLabel(StorageInfo::kindName(v.kind)+" ["+v.name+"]");
        dialog.addLabel("Pasta: "+v.mount);
        dialog.addLabel("Dispositivo: "+v.device);
        dialog.addLabel(v.capacityKnown ? "Livre: "+StorageInfo::formatBytes(v.free) : "Espaco indisponivel");
        if(v.capacityKnown) dialog.addLabel("Total: "+StorageInfo::formatBytes(v.total));
        if(v.readOnly)dialog.addLabel("Somente leitura");
        dialog.addOption(i+1<volumes_.size()?"Proximo":"Voltar");dialog.addOption("Fechar");dialog.init();
        if(dialog.execute()!=1)break;
    }
}
