#pragma once
#include <cstdint>
#include <istream>
#include <string>
#include <vector>

namespace StorageInfo {
enum class Kind { SdCard, Usb, Internal };
struct Volume {
    Kind kind;
    std::string device, mount, name;
    std::uint64_t free = 0, total = 0;
    bool capacityKnown = false, readOnly = false;
};
// Parses Linux mount data without executing commands; also used by fixture tests.
std::vector<Volume> parseMounts(std::istream &input);
std::vector<Volume> connected();
std::string kindName(Kind kind);
std::string formatBytes(std::uint64_t bytes);
std::string description(const Volume &volume);
}
