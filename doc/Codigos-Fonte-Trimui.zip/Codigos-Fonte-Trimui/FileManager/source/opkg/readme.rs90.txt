Commander: Two-pane file manager

Controls:

D-pad   Move
        Image viewer: previous / next image
A       For a directory: open
        For a file: view or execute
B       Go to parent directory / cancel
L       System actions:
          - Select all items
          - Select no items
          - Create new directory
          - Display disk information
          - Quit program
        Image viewer: toggle filename
R       Actions on selected items:
          - Copy to destination directory
          - Move to destination directory
          - Rename (appears only if 1 item is selected)
          - Delete
          - Display disk used
SELECT  Select highlighted item.
        Selected items are displayed in red.
START   Open highlighted directory in destination panel.
        If a file is highlighted, open current directory
        in the destination panel.

https://github.com/od-contrib/commander
