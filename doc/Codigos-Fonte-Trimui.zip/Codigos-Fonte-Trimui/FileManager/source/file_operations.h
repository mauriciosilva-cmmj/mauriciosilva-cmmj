#pragma once

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace FileOperations {
enum class Kind { Copy, Move, Remove, Extract };
enum class Decision { Yes, All, Skip, Cancel };
struct Progress {
    std::string phase, path;
    std::uint64_t done = 0, total = 0;
    std::uint64_t items = 0, itemTotal = 0;
    bool complete = false;
};
struct Callbacks {
    // All callbacks run on the calling thread. Return false to cancel safely.
    std::function<bool(const Progress &)> progress;
    std::function<Decision(const std::string &)> overwrite;
};
struct Result {
    bool cancelled = false;
    std::uint64_t skipped = 0;
    std::string error;
};
Result run(Kind kind, const std::vector<std::string> &sources,
    const std::string &destination, const Callbacks &callbacks);
}
