#pragma once
// Saves preferences only after explicit Save; leaves settings unchanged on Cancel.
bool OpenSettingsMenu();
