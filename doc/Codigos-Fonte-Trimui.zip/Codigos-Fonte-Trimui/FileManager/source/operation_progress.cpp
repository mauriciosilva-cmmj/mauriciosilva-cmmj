#include "operation_progress.h"
#include "config.h"
#include "def.h"
#include "dialog.h"
#include "error_dialog.h"
#include "resourceManager.h"
#include "screen.h"
#include "sdlutils.h"

#include <algorithm>
#include <cstdio>

namespace {
class ProgressWindow : public CWindow {
    FileOperations::Progress state;
    Uint32 lastRender = 0;
    bool first = true;
public:
    bool update(const FileOperations::Progress &next) {
        const bool phaseChanged = next.phase != state.phase;
        state = next;
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            const auto &cfg = config();
            if (event.type == SDL_KEYDOWN && (event.key.keysym.sym == cfg.key_parent || event.key.keysym.sym == SDLK_ESCAPE)) return false;
#ifdef USE_SDL2
            if (event.type == SDL_CONTROLLERBUTTONDOWN &&
                ControllerButtonFromSdlEvent(event) == cfg.gamepad_parent) return false;
            if (event.type == SDL_WINDOWEVENT && event.window.event == SDL_WINDOWEVENT_SIZE_CHANGED)
                screen.onResize(event.window.data1, event.window.data2);
#endif
            if (event.type == SDL_QUIT) return false;
        }
        const auto now = SDL_GetTicks();
        if (first || phaseChanged || next.complete || now - lastRender >= 40) {
            SDL_utils::renderAll();
            screen.flip();
            first = false; lastRender = now;
        }
        return true;
    }
    void render(bool) const override {
        const int w = std::min(screen.actual_w - 16, static_cast<int>(290 * screen.ppu_x));
        const int h = 7 * LINE_HEIGHT_PHYS + static_cast<int>(12 * screen.ppu_y);
        const int x = (screen.actual_w - w) / 2, y = (screen.actual_h - h) / 2;
        const int pad = std::max(4, static_cast<int>(8 * screen.ppu_x));
        const auto bg = SDL_MapRGB(screen.surface->format, COLOR_BG_1);
        const auto border = SDL_MapRGB(screen.surface->format, COLOR_BORDER);
        const auto fill = SDL_MapRGB(screen.surface->format, COLOR_CURSOR_1);
        SDL_Rect box = SDL_utils::makeRect(x, y, w, h);
        SDL_utils::renderRectWithBorder(screen.surface, box, 2, border, bg);
        const auto &fonts = CResourceManager::instance().getFonts();
        const SDL_Color fg{COLOR_TEXT_NORMAL}, back{COLOR_BG_1};
        int line = y + 6;
        const auto text = [&](const std::string &value) {
            // Crop long paths to the dialog, preserving valid UTF-8.
            auto *surface = SDL_utils::renderText(fonts, value, fg, back);
            if (surface) {
                SDL_Rect clip = SDL_utils::makeRect(std::max(0, surface->w - (w - 2 * pad)), 0, w - 2 * pad, surface->h);
                SDL_utils::applyPpuScaledSurface(x + pad, line, surface, screen.surface, &clip);
                SDL_FreeSurface(surface);
            }
            line += LINE_HEIGHT_PHYS;
        };
        text(state.phase);
        text(state.path);
        const bool preparing = state.phase == "Preparing";
        const int percentage = state.total ? static_cast<int>(std::min(100.0L, 100.0L * state.done / state.total)) : (state.complete ? 100 : 0);
        text(preparing ? "Calculating total..." : std::to_string(percentage) + "%");
        SDL_Rect bar = SDL_utils::makeRect(x + pad, line, w - 2 * pad, std::max(6, LINE_HEIGHT_PHYS - 5));
        SDL_utils::renderRectWithBorder(screen.surface, bar, 1, border, bg);
        bar.x += 1; bar.y += 1; bar.w -= 2; bar.h -= 2;
        if (preparing) {
            const int step = std::max(1, bar.w / 4);
            bar.x += (SDL_GetTicks() / 30) % std::max(1, bar.w - step);
            bar.w = step;
        } else bar.w = static_cast<int>(bar.w * percentage / 100);
        SDL_FillRect(screen.surface, &bar, fill);
        line += LINE_HEIGHT_PHYS;
        text(std::to_string(state.items) + " / " + std::to_string(state.itemTotal) + " items");
        char sizes[96];
        if (state.phase == "Deleting" || preparing) sizes[0] = '\0';
        else std::snprintf(sizes, sizeof(sizes), "%.1f / %.1f MiB", (state.done - state.items) / 1048576.0, (state.total - state.itemTotal) / 1048576.0);
        text(sizes);
        text("B / Back: Cancel");
    }
};
}

void RunFileOperation(FileOperations::Kind kind,
    const std::vector<std::string> &sources, const std::string &destination) {
    FileOperations::Result result;
    {
        ProgressWindow window;
        FileOperations::Callbacks callbacks;
        callbacks.progress = [&](const FileOperations::Progress &state) { return window.update(state); };
        callbacks.overwrite = [&](const std::string &path) {
            CDialog dialog("File already exists:");
            dialog.addLabel(path);
            dialog.addLabel("Overwrite?");
            dialog.addOption("Yes");
            dialog.addOption("Yes to all");
            dialog.addOption("Skip");
            dialog.addOption("Cancel");
            dialog.init();
            switch (dialog.execute()) {
                case 1: return FileOperations::Decision::Yes;
                case 2: return FileOperations::Decision::All;
                case 3: return FileOperations::Decision::Skip;
                default: return FileOperations::Decision::Cancel;
            }
        };
        result = FileOperations::run(kind, sources, destination, callbacks);
    }
    SDL_utils::renderAll();
    if (!result.error.empty()) ErrorDialog("Operation failed", result.error);
    else if (result.cancelled || result.skipped) {
        CDialog dialog(result.cancelled ? "Operation cancelled" : "Operation finished");
        if (result.skipped) dialog.addLabel(std::to_string(result.skipped) + " items skipped");
        if (result.cancelled) dialog.addLabel("Completed items were kept.");
        dialog.addOption("OK"); dialog.init(); dialog.execute();
    }
}
