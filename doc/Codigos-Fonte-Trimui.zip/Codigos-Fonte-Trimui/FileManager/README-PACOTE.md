# FileManager / Commander — código-fonte

- `source/`: fontes C++, testes, recursos e licença do projeto; inclui miniz e sua licença.
- `res/`, imagens, `config.json`, `trimui.cfg` e `launch.sh`: recursos e configuração padrão do aplicativo.
- `tools/SDL2/`, `tools/sdk/` e `lib/`: cabeçalhos e bibliotecas de apoio à compilação para o Trimui. Os arquivos `.so` são bibliotecas compiladas, não código-fonte. `licenses/` reúne licenças disponíveis.
- `tools/build-trimui.py`: compilação cruzada para ARM64 Linux; `tools/build-tests.py` e os testes em `source/tests/` ajudam na verificação local.

## Compilar no Windows

Instale Python 3 e Zig 0.13.0. A partir desta pasta, é possível instalar o Zig no caminho esperado pelo script e compilar:

```powershell
python -m pip install --target tools/python-zig ziglang==0.13.0
python tools/build-trimui.py
```

O resultado é `build/trimui/DinguxCommander`. A instalação do Zig depende de acesso ao repositório de pacotes Python. O script de prévia visual também depende das bibliotecas SDL para Windows, que não estão incluídas. Outras formas de compilação e dependências estão descritas em `source/README.md`.

Origem: https://github.com/od-contrib/commander ; revisão original `a6ef30eb3bd6ef80a031744aae0f5b9cd974c182`. O miniz incluído é da versão 3.0.2: https://github.com/richgel999/miniz/tree/3.0.2 . Informações adicionais estão em `source/ORIGEM.txt`.

`instalar-filemanager.sh` pertence ao pacote de instalação já gerado e verifica o hash do ZIP de instalação correspondente; não instala este pacote de fontes. A recompilação ou alteração do pacote de instalação exige atualizar o hash do instalador. Validação no console físico continua necessária.
