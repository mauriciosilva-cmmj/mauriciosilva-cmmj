#!/bin/sh
export LD_LIBRARY_PATH="/mnt/SDCARD/System/lib:/usr/trimui/lib:$LD_LIBRARY_PATH"
export PATH="/mnt/SDCARD/System/bin:$PATH"
. /mnt/SDCARD/Apps/Scraper/idioma.sh
selection=$(basename "$1" | sed 's/\.[^.]*$//')
case "$1" in *.sh) "$1"; exit $?;; esac
# Restrict the system identifier; the worker passes it to find and shell scripts.
case "$selection" in '° Scrape all') mode=--all;;
    *) case "$1" in ''|*[!A-Za-z0-9_-]*)
       if [ "$SCRAPER_PT" = 1 ]; then msg='Identificador de console invalido.'; else msg='Invalid console identifier.'; fi
       /mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh -m "$msg" -t 3; exit 1;;
       *) mode="$1";; esac;;
esac
dir=/tmp/crossmix_scraper_progress
mkdir -p "$dir" || exit 1
# Do not overlap a scraper started from another CrossMix entry point.
if pgrep -f '[s]crap_screenscraper.sh' >/dev/null 2>&1; then
    if [ "$SCRAPER_PT" = 1 ]; then msg='Ja existe uma consulta em andamento.'; else msg='A scraping task is already running.'; fi
    /mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh -m "$msg" -t 3; exit 1
fi
if ! mkdir "$dir/lock" 2>/dev/null; then
    pid=$(cat "$dir/lock/pid" 2>/dev/null)
    # Give a newly started worker time to publish its PID. A lock left
    # without one after an interrupted launch can then be recovered.
    if [ -z "$pid" ]; then
        sleep 2
        pid=$(cat "$dir/lock/pid" 2>/dev/null)
        if [ -z "$pid" ]; then
            rmdir "$dir/lock" 2>/dev/null && mkdir "$dir/lock" 2>/dev/null || exit 1
            pid=recovered
        fi
    fi
    if [ "$pid" != recovered ]; then
    case "$pid" in ''|*[!0-9]*) live=0;; *) if kill -0 "$pid" 2>/dev/null; then live=1; else live=0; fi;; esac
    if [ "$live" = 1 ] || [ -z "$pid" ]; then
       if [ "$SCRAPER_PT" = 1 ]; then msg='Ja existe uma consulta em andamento.'; else msg='A scraping task is already running.'; fi
       /mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh -m "$msg" -t 3; exit 1
    fi
    rm -f "$dir/lock/pid"
    rmdir "$dir/lock" 2>/dev/null && mkdir "$dir/lock" 2>/dev/null || exit 1
    fi
fi
rm -f "$dir/cancel_all" "$dir/status.json"
/mnt/SDCARD/Apps/Scraper/executar-fundo.sh "$mode" > /mnt/SDCARD/Apps/Scraper/scraper.log 2>&1 </dev/null &
if [ "$SCRAPER_PT" = 1 ]; then msg=$(printf 'Consulta iniciada em segundo plano.\nAbra o Scraper para acompanhar\nou cancelar.'); else msg=$(printf 'Scraping started in background.\nOpen Scraper to monitor\nor cancel.'); fi
/mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh -m "$msg" -fs 25 -t 3
