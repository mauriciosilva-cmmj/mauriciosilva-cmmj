#!/bin/sh
PATH="/mnt/SDCARD/System/bin:$PATH"
. /mnt/SDCARD/Apps/Scraper/idioma.sh
status=/tmp/crossmix_scraper_progress/status.json
if [ ! -r "$status" ]; then
    if [ "$SCRAPER_PT" = 1 ]; then msg='Nenhuma consulta em andamento.'; else msg='No scraping task running.'; fi
else
    snapshot=$(jq -r '[.system // "-", .phase // "-", .processed // 0, .total // 0, .percent // 0, .downloaded // 0, .existing // 0, .failed // 0] | map(tostring) | join("|")' "$status" 2>/dev/null)
    IFS='|' read -r sys phase done total pct ok exists fail <<EOF
$snapshot
EOF
    if [ "$SCRAPER_PT" = 1 ]; then
        case "$phase" in preparing) phase='Preparando';; running) phase='Consultando';; finished) phase='Concluido';; cancelled) phase='Cancelado';; interrupted) phase='Interrompido';; error) phase='Erro';; esac
    fi
    if [ "$SCRAPER_PT" = 1 ]; then
        msg=$(printf "Sistema: %s\n%s/%s - %s%%\nBaixadas: %s | Existentes: %s\nFalhas: %s | Estado: %s" "$sys" "$done" "$total" "$pct" "$ok" "$exists" "$fail" "$phase")
    else
        msg=$(printf "System: %s\n%s/%s - %s%%\nDownloaded: %s | Existing: %s\nErrors: %s | State: %s" "$sys" "$done" "$total" "$pct" "$ok" "$exists" "$fail" "$phase")
    fi
fi
/mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh -m "$msg" -fs 25 -t 8
