#!/bin/sh
PATH="/mnt/SDCARD/System/bin:$PATH"
. /mnt/SDCARD/Apps/Scraper/idioma.sh
dir=/tmp/crossmix_scraper_progress
pid=$(cat "$dir/lock/pid" 2>/dev/null)
case "$pid" in ''|*[!0-9]*) running=0;; *) if kill -0 "$pid" 2>/dev/null; then running=1; else running=0; fi;; esac
if [ "$running" = 1 ]; then
    touch "$dir/cancel_all"
    if [ "$SCRAPER_PT" = 1 ]; then msg=$(printf 'Cancelamento solicitado.\nAguarde a consulta atual terminar.'); else msg=$(printf 'Cancellation requested.\nWaiting for the current request.'); fi
else
    if [ "$SCRAPER_PT" = 1 ]; then msg='Nao ha consulta em andamento.'; else msg='No scraping task running.'; fi
fi
/mnt/SDCARD/System/usr/trimui/scripts/infoscreen.sh -m "$msg" -fs 25 -t 4
