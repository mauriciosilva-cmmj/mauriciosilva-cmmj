# Steam Big Picture para CrossMix

Versao 0.8.2 de um launcher com a aparencia do Big Picture, baseado nas
capturas fornecidas: inicio com carrossel, biblioteca de capas, menu lateral,
favoritos, colecoes, busca, aplicativos e ajustes de video/standby.

O MainUI original nao permite reorganizar livremente esses elementos apenas
por tema. Por isso o layout completo e um aplicativo SDL2 proprio. A pasta
`Themes/Steam Big Picture` inclui tambem uma variacao de cores para o MainUI;
essa variacao usa o layout do firmware. O launcher completo aparece em
**Apps > Steam Big Picture** e pode ser escolhido como interface ao ligar.

## Abrir no PC

Abra `D:\Trimui\dev\Abrir Big Picture.cmd`, ou no PowerShell:

O inicializador abre o Docker Desktop automaticamente quando necessario e
aguarda o mecanismo ficar pronto antes de iniciar a interface.

```powershell
cd D:\Trimui\dev
.\bigpicture.ps1 Start
.\bigpicture.ps1 Restart
.\bigpicture.ps1 Stop
```

A previa usa um executavel x86_64 nativo no Linux/WSLg. O codigo e o mesmo
compilado para ARM64, sem precisar traduzir o programa inteiro no PC.
Os jogos e aplicativos sao catalogados do pacote CrossMix. Na previa PC, jogos
de FC/NES, GB/GBC, GBA, PCE, SFC/SNES e Virtual Boy podem ser abertos pelo
RetroArch Linux; Atari 2600 e Doom usam seus emuladores Linux. Na aba
Aplicativos, o RetroArch tambem pode ser aberto.
Os outros aplicativos e sistemas ainda exigem suporte especifico no PC; a
interface informa quando uma opcao nao estiver disponivel. No aparelho, sao
usados os launchers do CrossMix, sujeitos a validacao no hardware.

Os arquivos de salvamento da previa ficam em
`D:\Trimui\dev\sdcard\Data\BigPicture\pc-retroarch`. No RetroArch, Esc fecha
o jogo e volta ao menu; F1 abre as opcoes do emulador. Use as setas e, para
começar, Enter; o mapa dos botoes pode ser ajustado no proprio RetroArch.

O projeto inclui a Free Games Collection. Alguns sistemas nao tem jogos: por
exemplo, `Roms/SEGA32X` esta vazia. Adicione seus jogos compativeis nessa
pasta e reinicie a interface para atualizar o catalogo. Apenas possuir o
emulador configurado nao adiciona jogos ao sistema.

| Tecla | Acao |
| --- | --- |
| Setas | Navegar |
| Enter / Espaco | Confirmar |
| Escape / Ctrl esquerdo | Voltar |
| F1 | Menu lateral |
| F6 / F7, Tab / Backspace | Trocar de secao; em Consoles, trocar de console |
| F3 | Buscar |
| F4 | Ordenar por nome/recentes |
| F9 / Shift esquerdo | Favoritar; nos videos, marcar/desmarcar ou escolher o fixo |
| F10 | Simular o interruptor Fn |
| F11 | Standby / Power |
| F12 | Reproduzir uma introducao |
| Volume + / Volume - | Ajustar volume global e exibir a barra temporaria |

O mapa inicial de controle segue A/B, direcionais e L/R; o mapeamento dos
botoes fisicos ainda precisa ser conferido no dispositivo. Os aplicativos
e emuladores continuam usando seus launchers CrossMix existentes. O menu
lateral agora inclui **Aplicativos**, com o catalogo de apps detectados pelo
CrossMix e abertura pelo launcher cadastrado. A previa do PC continua limitada
aos aplicativos/emuladores com suporte local.

O canto superior direito mostra o percentual da bateria e o volume global do
TrimUI. Os botoes fisicos de volume ajustam o volume nativo do sistema; uma
barra temporaria mostra o nivel escolhido. Na previa do PC, a bateria aparece
como indisponivel e as teclas Volume +/− controlam o volume dos sons e videos
da interface, sem mudar o volume geral do Windows.

Na tela inicial, **baixo** sai do carrossel e destaca a linha **Recentes,
Favoritos, Colecoes, Consoles**. Esquerda/direita alternam o foco e A/Enter
abre a secao. Baixo novamente acessa os quatro atalhos inferiores; cima volta
para a linha anterior. O analogico esquerdo segue o mesmo caminho e repete
a navegacao quando mantido inclinado.

Ao mover para os lados no carrossel, o foco avanca entre as capas. Ao atingir
o centro, a faixa desliza para manter o jogo escolhido centralizado; a arte do
fundo muda gradualmente. Os extremos da lista nao fazem a selecao saltar para
o outro lado. A animacao e baseada em tempo e termina quando a tela fica parada.

Na versao 0.7, o nome e a linha de informacoes do jogo tambem acompanham a
referencia: somem na troca e entram com fade de baixo para cima apos um curto
intervalo. Trocas rapidas reiniciam a entrada para o ultimo jogo selecionado.

A versao 0.6 foi ajustada pela gravacao enviada: a moldura fica presa a capa
escolhida, que aumenta suavemente; a faixa desliza e a arte do fundo aparece
gradualmente. A/Enter abre os detalhes do jogo, com capa ampliada, tempo de
jogo e botao Jogar. A novamente inicia; B retorna a mesma selecao.

Os 13 efeitos sonoros foram importados do Steam local para `Apps/BigPicture/sounds`.
O efeito de rolagem (`deck_ui_misc_10.wav`) e os sons de entrada/retorno dos
detalhes foram identificados por comparacao do audio da gravacao. Outros sons
originais acompanham confirmacao, abas, menu lateral e ajustes. Em Configuracoes,
**Sons da interface** ativa/desativa e **Volume da interface** ajusta somente
esses efeitos; as animacoes de inicio continuam com volume separado.

Para repetir a importacao: `.\importar-sons-steam.ps1`. A pasta de sons faz
parte do pacote do cartao. O driver de audio real e o volume do aparelho
continuam sujeitos a teste no TrimUI.

**Consoles** mostra os 110 sistemas configurados em um carrossel semelhante
ao de jogos recentes. As imagens dos aparelhos tem fundo transparente,
contorno seguindo a silhueta e sombra. O nome entra com o mesmo fade de baixo
para cima; o aparelho selecionado aumenta suavemente e a faixa acompanha o foco.
As imagens aproveitam as artes de aparelhos ja presentes no CrossMix.

Esquerda/direita ou **L1/R1** percorrem os consoles. Os jogos do console em
foco aparecem imediatamente abaixo, sem precisar abrir outra tela. **Baixo**
ou A entra nos jogos; esquerda/direita escolhe e A abre os detalhes. **Cima**
ou B retorna ao carrossel. L1/R1 tambem troca de console enquanto o foco esta
nos jogos. Ao voltar dos detalhes, o console e o jogo continuam selecionados.

Os consoles sem jogos continuam visiveis, com a pasta de ROMs indicada na
tela. A selecao para nas extremidades e o ultimo console fica salvo.
**Colecoes** agrupa as pastas de `Best`, como Free Games Collection. A contagem
de sistemas acompanha o conteudo do seu cartao.

Na biblioteca, em Favoritos e Aplicativos, o foco inicial fica nas
abas. Use esquerda/direita para alternar, e baixo
ou A para entrar nos itens. Se a aba estiver vazia, o foco vai direto para as
abas, permitindo navegar para outra sem usar L/R. Com foco nas capas, as
setas horizontais continuam percorrendo os jogos; cima na primeira linha
retorna as abas. L/R continua trocando abas nessas telas. Em Consoles, cima
no carrossel acessa as abas; L1/R1 permanece reservado aos consoles.

## Onde guardar seus videos

No PC:

`D:\Trimui\dev\sdcard\Data\BigPicture\videos\startup`

No cartao:

`Data/BigPicture/videos/startup`

Essa e a pasta para adicionar MP4 ou WebM. Para o console, prefira MP4 H.264,
1280x720, yuv420p e audio AAC. Os 14 videos ja importados estao convertidos
nesse formato. O manifesto associa nomes amigaveis aos arquivos e pode ser
editado. Os originais ficam em `videos/originais-steam`.

Foram encontrados treze arquivos personalizados em
`Steam/config/communityitemscache/startupmovies` e o Big Picture classico em
`Steam/steamui/movies`. Isso representa os arquivos que estavam baixados nesta
maquina; nao uma auditoria de todos os itens da conta Steam.

Para importar novamente depois que a Steam baixar outros videos:

```powershell
.\importar-videos-steam.ps1
.\bigpicture.ps1 Restart
```

Nao e necessario renomear um novo MP4 manual para usa-lo. Reinicie a previa para
reler a pasta. Uma miniatura JPG com o mesmo nome e opcional.

Em **Videos de inicio**, L/R (F6/F7 no PC) alterna os tres modos:

- **Aleatorio: todos**: usa todos os videos da pasta.
- **Aleatorio: marcados**: X (Shift/F9 no PC) marca ou desmarca cada video.
  Somente os marcados participam; sem marcacoes a introducao e pulada.
- **Um video fixo**: X escolhe o video que sera sempre apresentado.

A/Enter reproduz uma previa sem mudar a escolha. Cima no primeiro video leva
ao seletor de modo; baixo retorna a lista. As preferencias sao salvas para
o inicio e para o retorno do standby. Qualquer botao, direcao ou clique pula
a animacao; o comando e consumido para evitar ativar algo no menu ao retornar.
Em **Configuracoes**, tambem e possivel escolher o modo, ativar/desativar a
introducao no inicio e no retorno e ajustar o volume.

## Tela apagada e retorno

Padrao: 120 segundos de inatividade, retorno por qualquer botao, introducao no
inicio e no retorno. Em Configuracoes, o tempo pode ser desligado ou definido
em 30, 60, 120, 300 ou 600 segundos. As politicas de retorno sao qualquer botao,
Power e Fn.

Com a interface acordada, um toque no botao Power apaga a tela sem encerrar o
launcher. Outro toque em Power restaura a tela e reproduz uma introducao usando
a selecao atual: sorteio de todos, sorteio dos marcados ou video fixo. Power tambem acorda o aparelho mesmo se a politica
de despertar estiver configurada para outro botao. O interruptor Fn desligado
continua exigindo que o Fn seja ligado novamente.

O modo implementado e **standby de tela**: o launcher para de redesenhar, reduz
o trabalho enquanto espera entrada e, no TrimUI, envia brilho zero ao controle
de backlight do firmware. Ao retornar, restaura o brilho salvo e reproduz a
introducao antes de devolver o controle ao menu. No PC, apenas a janela fica
preta; o monitor e o Windows nao sao suspensos.

Se o standby foi provocado pelo Fn desligado, os outros botoes nao o desfazem:
e necessario ligar o Fn novamente. Isso corresponde ao comportamento pedido
para o interruptor inferior. F10 simula esse fluxo no PC.

Isso **nao e suspensao profunda do processador**. Nao se promete retorno de
`mem` por qualquer botao ou pelo Fn: isso depende das fontes de despertar do
kernel. Economia real de bateria, brilho e entrada fisica exigem teste no
TrimUI. O standby desta versao atua enquanto o launcher esta ativo; durante
um jogo, continuam valendo os controles de energia do firmware/emulador.

## Compilar / colocar no cartao

```powershell
.\bigpicture.ps1 Build
.\bigpicture.ps1 Package
```

O executavel ARM64 e salvo em `Apps/BigPicture/bin/bigpicture`. `Package` gera
`out/bigpicture/Steam-BigPicture-TrimUI-v0.8.2.zip`, com o aplicativo, o tema e
seus videos; exclui os logs e o estado da biblioteca de desenvolvimento.
Para uma
instalacao manual no cartao CrossMix, copie:

- `Apps/BigPicture`;
- `Data/BigPicture`;
- `Themes/Steam Big Picture`, caso queira tambem a variacao para o MainUI.

Abra o aplicativo antes de ativar a inicializacao automatica. Em Configuracoes,
**Iniciar ao ligar o console** cria um wrapper no proprio cartao, em
`trimui/app/MainUI`. Um launcher anterior e preservado em
`MainUI.before-bigpicture`. Ao sair do Big Picture, o wrapper chama o MainUI
original. A mesma opcao permite desativar e restaurar o launcher anterior.
Criar um arquivo vazio `Data/BigPicture/disable-boot` forca o wrapper a abrir
diretamente o MainUI original.

**Registrar opcao no editor Fn** faz backup do JSON do editor, adiciona o
script Big Picture e o registra na lista. Depois, abra o editor Fn do sistema
e escolha **Big Picture: standby**. Nenhuma dessas instalacoes foi executada
no hardware durante o desenvolvimento no PC.

## Arquivos para modificar

- `src/main.cpp`: interface, eventos, videos e estado de standby;
- `src/console_art.hpp`: recorte por transparencia, contorno e sombra dos consoles;
- `consoles/<ID>.png`: imagens transparentes dos aparelhos, substituiveis;
- `catalog.py`: leitura dos jogos, imagens e aplicativos do CrossMix;
- `power.sh`: controle do backlight no console e simulacao no PC;
- `com.crossmix.bigpicture.sh`: entrada do Fn;
- `Data/BigPicture/settings.json`: preferencias;
- `Data/BigPicture/library-state.json`: favoritos, recentes e tempo de jogo;
- `Data/BigPicture/events.jsonl`: registro das transicoes;
- `Data/BigPicture/runtime-status.json`: estado atual da previa.

O fornecedor JSON (nlohmann 3.11.3) e a fonte DejaVu acompanham suas licencas.

O player no TrimUI usa as saidas SDL de video e audio. A opcao OSC fica
restrita ao PC porque o mpv 0.32 do firmware testado nao inclui esse recurso.

## Alcance da validacao

Compilacao x86_64 e ARM64, carregamento ARM64 no QEMU, politicas de retorno,
catalogacao e fluxos de video/standby sao conferidos no PC. Inicializacao do
cartao, acionamento do Fn no firmware, backlight, consumo de bateria e
emuladores precisam de validacao fisica. O launcher e uma primeira versao
funcional inspirada na referencia; nao inclui os servicos online da Steam.
